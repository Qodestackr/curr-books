export const firebaseConfig = {
  apiKey: "AIzaSyCnlA3rLSKV_6k3AHj8lAgDtA5LanUJL58",
  authDomain: "pmsmaadeez.firebaseapp.com",
  projectId: "pmsmaadeez",
  storageBucket: "pmsmaadeez.appspot.com",
  messagingSenderId: "236182363398",
  appId: "1:236182363398:web:225e2187774d9a3bc19287",
  measurementId: "G-YRTF8YBMP6"
};
