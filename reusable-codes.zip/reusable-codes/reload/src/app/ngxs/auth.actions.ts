export interface AuthStateModel {
  user?: {
    token: string;
    data?: null;
  };

  login: {
    email: string;
    password: string;
  };

  isAuthenticated?: boolean;

  firstTimeLogin?: {
    isFirstTimeLogin: boolean;
    email: string;
    password: string;
    otp: any;
    message: string;
    question: {
      questionId: any;
      question: string;
    };
    newPassword?: string;
    confirmPassword?: string;
  };

  socialAuth?: {
    facebook?: {
      accessToken: string;
      userId: string;
    };
    google?: {
      idToken: string;
      userId: string;
    };
    microsoft?: {
      accessToken: string;
      userId: string;
    };
  };

  resetUserId?: {
    email: any;
    otp: any;
    newUserId: any;
  };

  resetPassword?: {
    email?: string;
    otp?: any;
    secretQuestion?: {
      questionId: string;
      question: string;
    };
    newPassword?: string;
    confirmPassword?: string;
  };

  /** TODO */
  securityQuestion?: {
    questionId: number;
    answer: string;
    emailId: string;
  };
}

export class Login {
  static readonly type = '[Auth] Login';
  constructor(public payload: { email: string; password: string }) {}
}

export class LoginLoading {
  static readonly type = '[Auth] Login Loading';
}

export class LoginSuccess {
  static readonly type = '[Auth] Login Success';
  constructor(public payload: { user: any }) {}
}

export class LoginFailure {
  static readonly type = '[Auth] Login Failure';
  constructor(public payload: { message: string; statusCode: string }) {}
}

export class FirstTimeLogin {
  static readonly type = '[Auth] First Time Login';
  constructor(
    public payload: {
      email: string;
      initialPassword: string;
      otp: any;
      question: {
        questionId: string;
        question: string;
      };
      newPassword: string;
      confirmPassword: string;
    }
  ) {}
}

export class FirstTimeLoginLoading {}
export class FirstTimeLoginSuccess {}
export class FirstTimeLoginFailure {}

// Reset User Id
export class ResetUserId {
  static readonly type = '[Auth Reset] Reset User Id';
  constructor(
    public payload: {
      userIdOrEmail: any;
      otp: any;
      newUserId: any;
    }
  ) {}
}

export class socialAuth {}

export class socialAuthLoading {}
export class socialAuthSuccess {}
export class socialAuthFailure {}

export class ResetUserIdLoading {}
export class ResetUserIdSuccess {}
export class ResetUserIdFailure {}

export class SetNewPassword {
  static readonly type = '[Auth] Set New Password';
  constructor(public payload: string) {}
}

export class SetConfirmPassword {
  static readonly type = '[Auth] Set Confirm Password';
  constructor(public payload: string) {}
}

export class Logout {
  static readonly type = '[Auth] Logout';
}

// QUESTION...
export class getSecretQuestions {
  static readonly type = '[Auth] Get Secret Questions';

  constructor(public payload: any) {}
}

export class getSecretQuestionsLoading {}

export class getSecretQuestionsSucccess {}

export class getSecretQuestionsFailure {}

export class SetSecurityQuestion {
  static readonly type = '[Auth] Set Security Question';
  constructor(
    public payload: {
      questionId: number;
      answer: string;
      emailId: string;
    }
  ) {}
}

export class SetSecurityQuestionLoading {}

export class SetSecurityQuestionSuccess {}

export class SetSecurityQuestionFailure {}
