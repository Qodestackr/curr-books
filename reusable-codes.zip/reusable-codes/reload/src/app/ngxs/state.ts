import { Action, State, StateContext } from '@ngxs/store';
import { Injectable } from '@angular/core';

import { Router } from '@angular/router';

import {
  LoginLoading,
  Login,
  LoginFailure,
  LoginSuccess,
  AuthStateModel,
  FirstTimeLogin,
  ResetUserId,
  SetSecurityQuestion,
  SetNewPassword,
  SetConfirmPassword,
} from './auth.actions';

@State<AuthStateModel>({
  name: 'auth',
  defaults: {
    user: {
      token: '',
    },
    // isFirstTimeLogin: false,
    // firstTimeLogin: {},
    login: {
      email: '',
      password: '',
    },
    resetUserId: {
      email: '',
      otp: [''],
      newUserId: '',
    },
  },
})
@Injectable()
export class AuthState {
  constructor(private router: Router) {}

  @Action(Login)
  login(ctx: StateContext<AuthStateModel>, action: Login) {
    // Perform authentication logic, e.g., calling an API
    const { email, password } = action.payload;
    // Modify state
    ctx.patchState({
      // user: null,
      login: {
        email,
        password,
      },
    });
    // Dispatch further actions if needed
    ctx.dispatch(new LoginLoading());
  }

  @Action(LoginLoading)
  loginLoading(ctx: StateContext<AuthStateModel>) {
    // Handle login loading state
  }

  @Action(LoginSuccess)
  loginSuccess(ctx: StateContext<AuthStateModel>, action: LoginSuccess) {
    // Handle login success state
    const { user } = action.payload;
    ctx.patchState({
      user,
    });
  }

  @Action(LoginFailure)
  loginFailure(ctx: StateContext<AuthStateModel>, action: LoginFailure) {
    // Handle login failure state
    const { message, statusCode } = action.payload;
    // Modify state accordingly
  }

  @Action(FirstTimeLogin)
  firstTimeLogin(ctx: StateContext<any>, action: FirstTimeLogin) {
    console.log('Trying to log as first time?');

    const payload = action.payload;
    ctx.patchState({
      email: payload.email,
      initialPassword: payload.initialPassword,
      otp: payload.otp,
      question: payload.question,
      newPassword: payload.newPassword,
      confirmPassword: payload.confirmPassword,
    });
  }

  @Action(ResetUserId)
  resetUserId(ctx: StateContext<any>, action: ResetUserId) {
    console.log('reset id...');

    const payload = action.payload;

    ctx.patchState({
      userIdOrEmail: payload.userIdOrEmail,
      otp: payload.otp,
      newUserId: payload.newUserId,
    });
  }

  @Action(SetSecurityQuestion)
  setSecurityQuestion(
    ctx: StateContext<AuthStateModel>,
    action: SetSecurityQuestion
  ) {
    const { questionId, answer, emailId } = action.payload;
    const state = ctx.getState();
    ctx.setState({
      ...state,
      securityQuestion: {
        questionId,
        answer,
        emailId,
      },
    });
  }

  @Action(SetNewPassword)
  setNewPassword(ctx: StateContext<AuthStateModel>, action: SetNewPassword) {
    const state = ctx.getState();
    ctx.setState({
      ...state,
      resetPassword: {
        ...state.resetPassword,
        newPassword: action.payload,
      },
    });
  }

  @Action(SetConfirmPassword)
  setConfirmPassword(
    ctx: StateContext<AuthStateModel>,
    action: SetConfirmPassword
  ) {
    const state = ctx.getState();
    ctx.setState({
      ...state,
      resetPassword: {
        ...state.resetPassword,
        confirmPassword: action.payload,
      },
    });
  }
}
