import { Selector } from '@ngxs/store';
import { AuthStateModel } from './auth.actions';
import { AuthState } from './state';

export class AuthSelectors {
  @Selector([AuthState])
  static getUser(state: AuthStateModel): any {
    return state.user;
  }

  @Selector([AuthState])
  static isFirstTimeLogin(state: AuthStateModel): any {
    return state.firstTimeLogin;
  }

  @Selector([AuthState])
  static getLoginState(state: AuthStateModel): any {
    return state.login;
  }

  // @Selector([AuthState])
  // static getSelectedEmail(state: AuthStateModel): any {
  //   return state.selectedEmail;
  // }

  // @Selector([AuthState])
  // static getUserId(state: AuthStateModel): any {
  //   return state.userId;
  // }

  @Selector([AuthState])
  static getNewPassword(state: AuthStateModel): string | undefined {
    return state.resetPassword?.newPassword;
  }

  @Selector([AuthState])
  static getConfirmPassword(state: AuthStateModel): string | undefined {
    return state.resetPassword?.confirmPassword;
  }

  @Selector([AuthState])
  static getFirstLogin(state: AuthStateModel) {
    return state.firstTimeLogin;
  }

  @Selector([AuthState])
  static getAllState(state: AuthStateModel): AuthStateModel {
    return state;
  }

  @Selector([AuthState])
  static getResetUserId(state: any) {
    return state;
  }

  @Selector([AuthState])
  static getSecurityQuestion(
    state: AuthStateModel
  ): AuthStateModel['securityQuestion'] {
    return state.securityQuestion;
  }

  @Selector([AuthState])
  static getResetPassword(
    state: AuthStateModel
  ): AuthStateModel['resetPassword'] {
    return state.resetPassword;
  }
}
