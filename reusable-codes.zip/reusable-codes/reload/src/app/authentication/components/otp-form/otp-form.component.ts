import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-otp-form',
  templateUrl: './otp-form.component.html',
})
export class OtpFormComponent implements OnInit {
  verificationCode: string[] = ['', '', '', '', '', ''];
  countdown: string = '05:00';
  countdownInterval: any;
  resendDisabled: boolean = false;

  ngOnInit() {
    this.startCountdown();
  }

  onVerificationCodeChange() {
    const code = this.verificationCode.join('');
    if (code.length === 6) {
      console.log('Verification code:', code);
    }
  }

  startCountdown() {
    let minutes = 5;
    let seconds = 0;

    this.countdownInterval = setInterval(() => {
      if (minutes === 0 && seconds === 0) {
        clearInterval(this.countdownInterval);
        this.resendDisabled = false;
        return;
      }

      if (seconds === 0) {
        minutes--;
        seconds = 59;
      } else {
        seconds--;
      }

      this.countdown = this.formatTime(minutes, seconds);
    }, 1000);
  }

  formatTime(minutes: number, seconds: number): string {
    const formattedMinutes = String(minutes).padStart(2, '0');
    const formattedSeconds = String(seconds).padStart(2, '0');
    return `${formattedMinutes}:${formattedSeconds}`;
  }

  resendEmail() {
    if (this.countdown !== '00:00') {
      return;
    }

    // Logic to resend the email
    // You can update the countdown and disable the "Resend" button if needed
    this.startCountdown();
    this.resendDisabled = true;
  }
}
