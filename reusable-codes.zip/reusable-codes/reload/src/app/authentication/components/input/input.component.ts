import { Component, Input } from '@angular/core';
import { FormControl, ValidationErrors } from '@angular/forms';

@Component({
  selector: 'app-input',
  templateUrl: './input.component.html',
})
export class InputComponent {
  @Input() type: string = '';
  @Input() label: string = '';
  @Input() placeholder: string = '';
  @Input() value: string = '';
  @Input() errorMessage: string = '';
  @Input() control = new FormControl();

  isPasswordType: boolean = false;
  isPasswordVisible: boolean = false;
  isTouched: boolean = false; // Flag to track if the input field has been touched

  togglePasswordVisibility(): void {
    this.isPasswordVisible = !this.isPasswordVisible;
  }

  hasError(): boolean {
    return this.control.invalid && (this.control.dirty || this.isTouched);
  }

  toggleTouch() {
    this.isTouched = true; // Set touch state to true when the input field loses focus
  }

  getErrorMessage(): string | null {
    if (this.hasError()) {
      const errors: ValidationErrors | null = this.control.errors;
      if (errors) {
        if (errors['minlength'] && this.type !== 'password') {
          return this.getDefaultErrorMessage();
        }
        const errorKey = Object.keys(errors)[0];
        const errorMessages = this.getErrorMessages();
        return errorMessages[errorKey] || this.getDefaultErrorMessage();
      }
    }
    return null;
  }

  getErrorMessages(): Record<string, string> {
    return {
      required: 'This field is required',
      email: 'Invalid email address',
      minlength: 'Password should be at least 8 characters long',
    };
  }

  getDefaultErrorMessage(): string {
    return 'Invalid input';
  }
}
