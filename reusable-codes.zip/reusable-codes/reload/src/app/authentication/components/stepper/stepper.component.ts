import { Component } from '@angular/core';

@Component({
  selector: 'app-stepper',
  templateUrl: './stepper.component.html'
})
export class StepperComponent {
  currentStep = 2; // Example value, update as per your form progress
  steps = ['Security question', 'Optional Step 2', 'Password'];

  isStepCompleted(index: number): boolean {
    return this.currentStep > index;
  }

  stepItemClasses(index: number): string {
    return `flex justify-between items-center flex-col gap-1 step-item ${this.isStepCompleted(index) ? 'completed' : ''}`;
  }

  // nextStep(): void {
  //   if (this.currentStep < this.steps.length - 1) {
  //     this.currentStep++;
  //   }
  // }

  // isLastStep(): boolean {
  //   return this.currentStep === this.steps.length - 1;
  // }

}
