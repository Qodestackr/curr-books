// social-button component
import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-social-button',
  templateUrl: './social-button.component.html',
})
export class SocialButtonComponent {
  @Input() icon!: string;
  @Input() name!: string;

  @Output() loginWithProvider: EventEmitter<string> = new EventEmitter<string>();


  getIconSrc(name: string): string {
  if (name === 'Google') {
    return '../../../../assets/google_icon.svg';
  } else if (name === 'Facebook') {
    return '../../../../assets/fb__icon.svg';
  } else if (name === 'Microsoft') {
    return '../../../../assets/microsoft_icon.svg';
  }
  // Return a default icon source if needed
  return '';
}

}
