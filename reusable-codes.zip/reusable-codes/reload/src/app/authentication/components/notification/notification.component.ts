import { Component, Input, Output, EventEmitter, OnInit, OnDestroy } from '@angular/core';

@Component({
  selector: 'app-notification',
  templateUrl: './notification.component.html'
})
export class NotificationComponent implements OnInit, OnDestroy {
  @Input() message!: string;
  @Input() type!: string; // TODO use types to limit & provide docs success | warning | error | info
  @Input() timeout?: number;
  @Output() closed: EventEmitter<void> = new EventEmitter<void>();
  // Assuming we will add X button to close it...

  private timeoutId: any;

  ngOnInit(): void {
    if (this.timeout && this.timeout > 0) {
      this.timeoutId = setTimeout(() => {
        this.handleClosed();
      }, this.timeout);
    }
  }

  ngOnDestroy(): void {
    clearTimeout(this.timeoutId);
  }

  handleClosed():void{
    console.log("clicked to close"); // debugger for now
    this.closed.emit();
  }
}
