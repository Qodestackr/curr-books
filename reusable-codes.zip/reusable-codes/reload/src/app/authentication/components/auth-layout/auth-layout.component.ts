import { Component, Input } from '@angular/core';
import { layoutType } from './auth.types';

@Component({
  selector: 'app-auth-layout',
  templateUrl: './auth-layout.component.html',
})
export class AuthLayoutComponent {
  @Input() formTitle: string = '';
  @Input() formDescription: string = '';
  @Input() heroText: string = '';
  @Input() heroTextStrong: string = '';

  // hacky way: check layout type to determine what to render
  // i.e stepper and (orlogo<reload>)
  @Input() formLayoutType: layoutType = 'login';

}
