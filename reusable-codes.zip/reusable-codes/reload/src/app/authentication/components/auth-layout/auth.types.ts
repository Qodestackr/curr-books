export type layoutType = 'forgot-password' | 'forgot-userid' | 'login';
