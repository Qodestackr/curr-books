import { Component, Input } from '@angular/core';

type ResetType = 'userId' | 'password'


@Component({
  selector: 'app-confirmation-popup',
  templateUrl: './confirmation-popup.component.html',
})
export class ConfirmationPopupComponent {
  @Input() resetType: ResetType = 'userId';

}
