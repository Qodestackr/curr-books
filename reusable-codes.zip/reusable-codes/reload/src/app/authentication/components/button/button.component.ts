import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-button',
  templateUrl: './button.component.html',
})
export class ButtonComponent {
  @Input() label!: string;
  @Input() type! : string;
  @Input() icon? : string;
  @Input() disabled?: boolean;
  @Input() additionalClass?: string = '';

  @Output() clicked: EventEmitter<any> = new EventEmitter<any>();

  onClick(): void {
    this.clicked.emit();
  }

  baseButtonStyles(){
    return 'mt-4 w-full bg-[#0EA5E9] text-white py-2 px-4 rounded';
  }

}
