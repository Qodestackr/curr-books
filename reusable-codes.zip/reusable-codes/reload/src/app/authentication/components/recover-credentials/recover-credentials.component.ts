import { Component } from '@angular/core';

@Component({
  selector: 'app-recover-credentials',
  templateUrl: './recover-credentials.component.html',
})
export class RecoverCredentialsComponent {

}
