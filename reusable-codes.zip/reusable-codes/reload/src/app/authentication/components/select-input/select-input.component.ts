import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-select-input',
  templateUrl: './select-input.component.html',
})
export class SelectInputComponent {

  @Input() label!: string;
  @Input() options!: any[]; // Replace `any` with the type of your options
  @Output() selectedValueChange: EventEmitter<any> = new EventEmitter<any>();

  // Handle the selection change event
  onSelectChange(event: any) {
    const selectedValue = event.target.value;
    this.selectedValueChange.emit(selectedValue);
  }
}
