import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-form-step-label',
  templateUrl: './form-step-label.component.html',

})
export class FormStepLabelComponent {
  @Input() formTitle: string = '';
  @Input() formDescription: string = '';
}
