import { Component, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-form-security-question',
  templateUrl: './form-security-question.component.html',
})
export class FormSecurityQuestionComponent {
  @Output() nextStep: EventEmitter<void> = new EventEmitter<void>();

  handleNextStep(): void {
    this.nextStep.emit();
  }
}

// TODO, rename to be precise
