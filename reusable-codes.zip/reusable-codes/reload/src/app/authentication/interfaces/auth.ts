interface IAuthState {
  isLoggedIn: boolean;
  isFirstTimeLogin: boolean;
  // Add other fields related to authentication
}

interface IBaseUser<T> {
  userId: T;
  accountStatus: string;
}

interface ISecretQuestion {
  questionId?: number;
  question: string;
  status?: string;
}

interface IPasswordResetRequest {
  userId: number; // The ID of the user requesting password reset
  email: string; // The email associated with the user account
}

interface IPasswordReset {
  userId: number; // The ID of the user resetting the password
  newPassword: string; // The new password to set
}

interface IUserCredentials {
  loginName: string; // The username or login name of the user
  password: string; // The password associated with the user account
}

interface IUserProfile {
  userId: number; // The ID of the user
  firstName: string; // The first name of the user
  lastName: string; // The last name of the user
  email: string; // The email address of the user
  // Add additional fields related to user profile information
}

interface IUserRegistration {
  firstName: string; // The first name of the user
  lastName: string; // The last name of the user
  email: string; // The email address of the user
  password: string; // The password for the user account
  // Add additional fields required for user registration
}

interface IAuthenticationResult {
  success: boolean; // Indicates if the authentication was successful
  message?: string; // A message related to the authentication result
  // Add additional fields as needed, such as tokens or user information
}
