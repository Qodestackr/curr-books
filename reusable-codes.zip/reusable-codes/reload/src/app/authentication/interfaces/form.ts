interface ILoginForm{
  userIdOrEmail: string;
  initialPassword: string;
  _notFirstTimepassword: string;
  _notFirstTimeUserIdOrEmail: string;
  email: string;
  securityAnswer: string;
  newPassword: string;
  confirmPassword: string;
  // otp, etc...
}

interface IResetPassword{

}

interface IResetUserID{

}
