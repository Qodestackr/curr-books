export interface User {
  id: number;
  username: string;
  email: string;
  // Add additional properties as needed
}
