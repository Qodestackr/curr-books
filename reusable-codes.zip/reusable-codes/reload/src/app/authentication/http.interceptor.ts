import { Injectable } from '@angular/core';
import {
  HttpInterceptor,
  HttpRequest,
  HttpHandler,
  HttpHeaders,
} from '@angular/common/http';
import { AuthService } from './auth.service';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {
  constructor(private authService: AuthService) {} // Inject your AuthService or the service containing the `authHeader()` function

  intercept(request: HttpRequest<any>, next: HttpHandler) {
    if (request.method === 'POST') {
      const modifiedRequest = request.clone({
        headers: new HttpHeaders(this.authService.authHeader()), // Include the authHeader() function in the headers
      });

      return next.handle(modifiedRequest);
    }

    return next.handle(request);
  }
}

/***
 *
 * import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { AuthInterceptor } from './http.interceptor';

 *
 * @NgModule({
  // ...
  providers: [
    // ...
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true,
    },
  ],
})
export class AppModule {}

 */
