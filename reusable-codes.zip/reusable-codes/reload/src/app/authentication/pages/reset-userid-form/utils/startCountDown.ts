import { formatTime } from "./timeFormat";

export function startCountdown(_this: any) {
    let minutes = 5;
    let seconds = 0;

    _this.countdownInterval = setInterval(() => {
      if (minutes === 0 && seconds === 0) {
        clearInterval(_this.countdownInterval);
        _this.resendDisabled = false;
        return;
      }

      if (seconds === 0) {
        minutes--;
        seconds = 59;
      } else {
        seconds--;
      }

      _this.countdown = formatTime(minutes, seconds)
    }, 1000);
}
