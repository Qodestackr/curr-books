export const DEFAULT_CURRENT_STEP = 1;
export const COUNT_DOWN_MINUTES: number = 5;
export const COUNT_DOWN_SECONDS: number = 0;
export const COUNT_DOWN_INTERVAL: null = null;
export const IS_RESEND_DISABLED: boolean = false;
