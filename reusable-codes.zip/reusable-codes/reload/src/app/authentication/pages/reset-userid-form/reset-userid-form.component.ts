import { Component, NgZone } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../auth.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';

import { changeStepHandler } from './utils/changeStepHandler';
import { startCountdown as _startCountdown } from './utils/startCountDown';

//////////////////////////////////
import { AuthSelectors } from 'src/app/ngxs/auth.selectors';
import { Store as _Store } from '@ngxs/store';
import { ResetUserId } from 'src/app/ngxs/auth.actions';
/////////////////////////////////

import {
  DEFAULT_CURRENT_STEP,
  COUNT_DOWN_MINUTES,
  COUNT_DOWN_SECONDS,
  COUNT_DOWN_INTERVAL,
  IS_RESEND_DISABLED,
} from './defaults';
import { resetUserId } from '../../actions/actions';

@Component({
  selector: 'app-reset-userid-form',
  templateUrl: './reset-userid-form.component.html',
})
export class ResetUseridFormComponent {
  verificationCode: string[] = ['', '', '', '', '', ''];
  countdown: string = '05:00';
  countdownInterval: any;
  resendDisabled: boolean = IS_RESEND_DISABLED;

  currentStep: number = DEFAULT_CURRENT_STEP;
  currentStepTitle: string = 'Reset your User Id';
  currentStepDescription: string =
    'Please enter the user ID/email address that is linked with your account';

  isLastStep: boolean = false;

  state = {
    email: '',
    otp: [''],
    newUserId: '',
  };

  formGroup = new FormGroup({
    // userId: new FormControl('', [Validators.required]),
    // email: new FormControl('', [Validators.required, Validators.email]),
    userIdOrEmail: new FormControl('', [
      Validators.required,
      Validators.pattern(/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/),
    ]),
    OTPVerificationCode: new FormControl('', [
      Validators.required,
      Validators.pattern(/^\d{6}$/),
    ]),
    newUserId: new FormControl('', [
      Validators.required,
      Validators.minLength(5),
    ]),
  });

  constructor(
    private router: Router,
    private authService: AuthService,
    public ngZone: NgZone,
    public store: _Store
  ) {}

  get UserIdOrEmailControl(): FormControl {
    return this.formGroup.get('userIdOrEmail') as FormControl;
  }

  get OTPVerificationCodeControl(): FormControl {
    return this.formGroup.get('OTPVerificationCode') as FormControl;
  }

  get NewUserIdControl(): FormControl {
    return this.formGroup.get('newUserId') as FormControl;
  }

  changeStep(step: number) {
    changeStepHandler(step, this);
  }

  handleResetUserId() {
    // this.router.navigate(['/', 'confirm-popup'])
    this.isLastStep = true;

    this.store.dispatch(
      new ResetUserId({
        userIdOrEmail: this.formGroup.get('userIdOrEmail')?.value,
        otp: this.formGroup.get('OTPVerificationCode')?.value,
        newUserId: this.formGroup.get('newUserId')?.value,
      })
    );
  }

  sendResetEmail() {
    this.changeStep(2);
  }
  verifyOTP() {
    // Move to step 3
    this.changeStep(3);
  }

  handleResetPassword() {
    this.isLastStep = true;
  }

  onVerificationCodeChange() {
    // Implement your verification code logic here if needed
  }

  startCountdown() {
    _startCountdown(this);
  }

  resendEmail() {
    if (this.countdown !== '00:00') {
      return;
    }

    // Logic to resend the email
    // Update the countdown and disable the "Resend" button if needed
    this.startCountdown();
    this.resendDisabled = true;
  }

  ngOnInit() {
    this.startCountdown();
    this.formGroup.valueChanges.subscribe((val) => console.log(this.formGroup));

    this.store
      .select(AuthSelectors.getAllState)
      .subscribe((resetUserIdState) => {
        console.log('states', resetUserIdState);
      });
  }
}
