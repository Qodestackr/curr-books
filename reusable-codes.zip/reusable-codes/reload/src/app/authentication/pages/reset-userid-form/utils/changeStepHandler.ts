export function changeStepHandler(step: number, thisCtx: any) {
    thisCtx.currentStep = step;
    switch (step) {
    case 1:
      thisCtx.currentStepTitle = 'Reset your User Id';
      thisCtx.currentStepDescription = 'Please enter the user ID/email address that is linked with your account';
      break;
    case 2:
      thisCtx.currentStepTitle = 'Check your email';
      thisCtx.currentStepDescription = 'We just sent you an email with the password reset instructions to your email address which is associated with this user id:';
      break;
    case 3:
      thisCtx.currentStepTitle = 'Security question: protected and unique.';
      thisCtx.currentStepDescription = 'Choose your own unique security and submit the answer you have informed us.';
      break;
    default:
      thisCtx.currentStepTitle = 'Change your User Id';
      thisCtx.currentStepDescription = 'Please enter the user ID/email address that is linked with your account';
      break;
  }
}
