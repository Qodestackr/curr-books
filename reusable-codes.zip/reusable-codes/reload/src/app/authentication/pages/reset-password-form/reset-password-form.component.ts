import { Component, NgZone } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../auth.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';


@Component({
  selector: 'app-reset-password-form',
  templateUrl: './reset-password-form.component.html',
})
export class ResetPasswordFormComponent {
  verificationCode: string[] = ['', '', '', '', '', ''];
  countdown: string = '05:00';
  countdownInterval: any;
  resendDisabled: boolean = false;

  currentStep: number = 1;
  currentStepTitle: string = 'Reset your password';
  currentStepDescription: string = 'Please enter the user ID/email address that is linked with your account';

  isLastStep: boolean = false;

  formGroup = new FormGroup({
    firstName: new FormControl('',[Validators.required]),
    lastName: new FormControl('', [Validators.required]),
    email: new FormControl('', [Validators.required, Validators.email]),
    password: new FormControl('',[Validators.required, Validators.minLength(8)])
  })

  constructor(private router: Router, private authService: AuthService, public ngZone: NgZone){
    this.formGroup.valueChanges.subscribe(val=>console.log(this.formGroup))
  }

  sendResetEmail() {
    // Move to step 2
    this.changeStep(2);
  }

  verifyOTP() {
    // Move to step 3
    this.changeStep(3);
  }

  checkSecurityQuestion() {
    // Move to step 4
    this.changeStep(4);
  }

  handleResetPassword() {
    // Move to the next step or display the confirmation popup
    // if (this.currentStep < 4) {
    //   this.changeStep(this.currentStep + 1);
    // } else {
    //   this.isLastStep = true;
    // }
      // this.changeStep(5);
      this.isLastStep = true

  }

  get firstNameControl(): FormControl {
    return this.formGroup.get('firstName') as FormControl;
  }

    get EmailControl(): FormControl {
    return this.formGroup.get('email') as FormControl;
  }
  get PasswordControl(): FormControl{
    return this.formGroup.get('password') as FormControl
  }

  changeStep(step: number) {
    this.currentStep = step;

    switch (step) {
      case 1:
        this.currentStepTitle = 'Reset your password';
        this.currentStepDescription = 'Please enter the user ID/email address that is linked with your account';
        break;
      case 2:
        this.currentStepTitle = 'Check your email';
        this.currentStepDescription =
          `We just sent you an email with the password reset instructions to your email address which is associated with this user id:`;
        break;
      case 3:
        this.currentStepTitle = 'Security question: protected and unique.';
        this.currentStepDescription =
          `Choose your own unique security and submit the answer you have informed us.`;
        break;
      default:
        this.currentStepTitle = 'Change your password';
        this.currentStepDescription =
          `Your password must be at least 8 characters long and contain both letters and numbers.`;
        break;
    }
  }

  onVerificationCodeChange() {
    // Implement your verification code logic here if needed
  }

  startCountdown() {
    let minutes = 5;
    let seconds = 0;

    this.countdownInterval = setInterval(() => {
      if (minutes === 0 && seconds === 0) {
        clearInterval(this.countdownInterval);
        this.resendDisabled = false;
        return;
      }

      if (seconds === 0) {
        minutes--;
        seconds = 59;
      } else {
        seconds--;
      }

      this.countdown = this.formatTime(minutes, seconds);
    }, 1000);
  }

  formatTime(minutes: number, seconds: number): string {
    const formattedMinutes = String(minutes).padStart(2, '0');
    const formattedSeconds = String(seconds).padStart(2, '0');
    return `${formattedMinutes}:${formattedSeconds}`;
  }

  resendEmail() {
    if (this.countdown !== '00:00') {
      return;
    }

    // Logic to resend the email
    // You can update the countdown and disable the "Resend" button if needed
    this.startCountdown();
    this.resendDisabled = true;
  }

  ngOnInit() {
    this.startCountdown();
  }
}
