import { Component, NgZone } from '@angular/core';
import { Router, NavigationExtras } from '@angular/router';
import { HttpHeaders } from '@angular/common/http';

import { Select, Store as _Store } from '@ngxs/store';

////////////
import { AuthSelectors } from 'src/app/ngxs/auth.selectors';
import { state as Loginstate } from './utils/loginState';

import {
  AuthStateModel,
  SetConfirmPassword,
  SetNewPassword,
  SetSecurityQuestion,
} from 'src/app/ngxs/auth.actions';

import { FirstTimeLogin, Login } from 'src/app/ngxs/auth.actions';

import { initializeForm } from './utils/initalizeLoginForm';
///////////

import {
  FormGroup,
  FormControl,
  ValidatorFn,
  AbstractControl,
  ValidationErrors,
} from '@angular/forms';

//////////////////////////////////////////////

import { AuthService } from '../../auth.service';
import {
  STEP_ONE_TITLE,
  STEP_ONE_DESCRIPTION,
  STEP_TWO_TITLE,
  STEP_TWO_DESCRIPTION,
  STEP_THREE_TITLE,
  STEP_THREE_DESCRIPTION,
  STEP_FOUR_TITLE,
  STEP_FOUR_DESCRIPTION,
} from './step-data';
import { Observable } from 'rxjs';
//////////////////////////////////////////////

@Component({
  selector: 'app-login-form',
  templateUrl: './login-form.component.html',
})
export class LoginFormComponent {
  OTPVerificationCode: string[] = ['', '', '', '', '', ''];
  selectedValue: string = '';
  currentStep: number = 1;
  currentStepTitle: string = 'Welcome back to Reload';
  currentStepDescription: string =
    'Logging in to Reload to continue managing your tenant wisely';

  isFirstTimeLogin: boolean = true;

  formGroup!: FormGroup;

  ////////////////////////////
  questions: any[] = [];
  selectedQuestionId: number | null = null;
  answer: string = '';

  confirmPassword$!: string;

  state = Loginstate; // state...

  ////////////////////////////

  // SELECTORS
  @Select(AuthSelectors.getSecurityQuestion) securityQuestion$!: Observable<
    AuthStateModel['securityQuestion']
  >;

  @Select(AuthSelectors.getResetPassword) newPassword$!: Observable<
    AuthStateModel['resetPassword']
  >;

  ////////////////////////////////////

  passwordMatchValidator: ValidatorFn = (
    control: AbstractControl
  ): ValidationErrors | null => {
    const newPassword = control.get('newPassword')?.value;
    const confirmPassword = control.get('confirmPassword')?.value;

    return newPassword === confirmPassword ? null : { passwordMismatch: true };
  };

  constructor(
    private router: Router,
    private authService: AuthService,
    public ngZone: NgZone,
    private _store: _Store
  ) {}

  ngOnInit(): void {
    initializeForm(this.formGroup, this);

    this._store.select(AuthSelectors.getAllState).subscribe((allState) => {
      this.state = allState;
      console.log('allState', allState);
    });

    this.formGroup.valueChanges.subscribe((val: any) => {
      // console.log(val);
    });

    this.getQuestions();

    // Forgot password test:
    ///////////////////////////
    const email = 'mikenzik@gmail.com';
    this.authService.sendResetPasscode(email).subscribe(
      (response) => {
        console.log('response');
        // Handle success response here
      },
      (error) => {
        console.log(error);
        // Handle error response here
      }
    );
    //////////////////////////
  }

  get UserIdOrEmailControl(): FormControl {
    return this.formGroup.get('userIdOrEmail') as FormControl;
  }

  get EmailControl(): FormControl {
    return this.formGroup.get('email') as FormControl;
  }

  get PasswordControl(): FormControl {
    return this.formGroup.get('initialPassword') as FormControl;
  }

  get NewPasswordControl(): FormControl {
    return this.formGroup.get('newPassword') as FormControl;
  }

  get ConfirmNewPasswordControl(): FormControl {
    return this.formGroup.get('confirmPassword') as FormControl;
  }

  get AnswerControl(): FormControl {
    return this.formGroup.get('securityAnswer') as FormControl;
  }

  // Change steps
  changeStep(step: number) {
    this.currentStep = step;
    if (step === 1) {
      this.currentStepTitle = STEP_ONE_TITLE;
      this.currentStepDescription = STEP_ONE_DESCRIPTION;
    } else if (step === 2) {
      this.currentStepTitle = STEP_TWO_TITLE;
      this.currentStepDescription = STEP_TWO_DESCRIPTION;
    } else if (step === 3) {
      this.currentStepTitle = STEP_THREE_TITLE;
      this.currentStepDescription = STEP_THREE_DESCRIPTION;
    } else if (step === 4) {
      this.currentStepTitle = STEP_FOUR_TITLE;
      this.currentStepDescription = STEP_FOUR_DESCRIPTION;
    }
  }

  goToStepTwo() {
    this.changeStep(3);
  }

  goToStepThree() {
    this.changeStep(4);
    this.isFirstTimeLogin = false;
  }

  goToStepFour() {
    const newPassword = this.NewPasswordControl.value;
    const confirmPassword = this.ConfirmNewPasswordControl.value;

    console.log(newPassword, confirmPassword);

    if (newPassword && confirmPassword && newPassword === confirmPassword) {
      // Dispatch actions to update the state
      this._store.dispatch(new SetNewPassword(newPassword));
      this._store.dispatch(new SetConfirmPassword(confirmPassword));

      // Call the resetPassword method from the AuthService
      this.authService
        .resetPassword(newPassword)
        .then((response: any) => {
          console.log('Password reset successful::service', response);
          this.changeStep(5);
        })
        .catch((error: any) => {
          console.error('Password reset failed::service', error);
          // Handle error case if needed
        });
    } else {
      console.log('Passwords do not match!');
    }
  }

  updateNewPassword(newPassword: string) {
    this._store.dispatch(new SetNewPassword(newPassword));
  }

  updateConfirmPassword(confirmPassword: string) {
    this._store.dispatch(new SetConfirmPassword(confirmPassword));
  }

  checkFirstTimeLogin(): void {
    this.changeStep(2);
  }

  getQuestions() {
    this.authService.getSecretQuestions().subscribe(
      (response: any) => {
        this.questions = response?.data || [];
        console.log(this.questions);
      },
      (error: any) => {
        console.log(error);
      }
    );
  }

  onQuestionChange() {
    console.log('Selected Question ID:', this.selectedQuestionId);
    const answer = this.AnswerControl.value;

    if (this.selectedQuestionId !== null) {
      this._store.dispatch(
        new SetSecurityQuestion({
          questionId: this.selectedQuestionId!,
          answer,
          emailId:
            'kar@gmail.com' /** this.state.login.email ??::Remove after tests */,
        })
      );
    }
  }

  loginF(providerName?: string, loginForm?: FormGroup): void {
    if (providerName) {
      // Social login logic
      if (providerName === 'Google') {
        this.authService
          .googleLogin()
          .then((result) => {
            // this.router.navigate(['dashboard']);
            console.log('Successful social login with Google', result);
          })
          .catch((error) => {
            console.log('Error occurred during social login:', error);
          });
      } else if (providerName === 'Facebook') {
        this.authService
          .facebookLogin()
          .then(() => {
            // this.router.navigate(['dashboard']);
            console.log('Successful social login with Facebook');
          })
          .catch((error) => {
            console.log('Error occurred during social login:', error);
          });
      } else if (providerName === 'Microsoft') {
        this.authService
          .microsoftLogin()
          .then(() => {
            this.router.navigate(['dashboard']);
            console.log('Successful social login with Microsoft');
          })
          .catch((error) => {
            console.log('Error occurred during social login:', error);
          });
      }
    } else {
      // Form-based login logic
      if (loginForm && loginForm.invalid) {
        return;
      }

      const userIdOrEmail = this.UserIdOrEmailControl.value;
      const password = this.PasswordControl.value;

      this.changeStep(2);

      // Perform form-based login
      this.authService
        .login({
          /**email: userIdOrEmail, password  */
          email: 'kar@gmail.com',
          password: 'kar@gmail.com',
        })
        .subscribe(
          (response: any) => {
            console.log(
              'Login successful::Form 319 line number',
              response.message
            );

            if (response.statusCode === 'AUTH007') {
              console.log(
                'Will handle the Logic for You here! First Timer for OTP access'
              );
              this.changeStep(2);
            } else {
              console.log('Not a first timer and will move elsewhere');
              // Handle other cases, such as successful login without password change required
              // Redirect to the main dashboard or perform other actions
              // Example: this.router.navigate(['/dashboard']);
              this.router.navigate(['/dashboard']);
            }
          },
          (error) => {
            console.log('Login failed:', error);
            // Handle login error, e.g., display an error message
          }
        );
    }
  }
}
