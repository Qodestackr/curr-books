import { AuthStateModel } from 'src/app/ngxs/auth.actions';

export const state: AuthStateModel = {
  user: {
    token: '',
  },
  firstTimeLogin: {
    isFirstTimeLogin: false,
    email: '',
    password: '',
    otp: null,
    message: '',
    question: {
      questionId: '',
      question: '',
    },
    newPassword: '',
    confirmPassword: '',
  },
  login: {
    email: '',
    password: '',
  },
};
