export const STEP_ONE_TITLE = `Welcome back to Reload`;

export const STEP_ONE_DESCRIPTION = `
Logging in to Reload to continue managing your tenant wisely
`;

export const STEP_TWO_TITLE = `Check your email`;
export const STEP_TWO_DESCRIPTION = `
We just sent you an email with password reset instruction to your email associated with this user Id.`;

export const STEP_THREE_TITLE = `Be Protective with the security question`;

export const STEP_THREE_DESCRIPTION = `
Stay ahead of the potential threats with an added layer of protection. Set up a security question and keep your account secure.`;

export const STEP_FOUR_TITLE = `To Stay Protected: Create a password`;

export const STEP_FOUR_DESCRIPTION = `
Protect your account from unauthorized access by creating a password as a first-time user`;

export const STEP_FIVE_TITLE = ``;
export const STEP_FIVE_DESCRIPTION = `

`;
