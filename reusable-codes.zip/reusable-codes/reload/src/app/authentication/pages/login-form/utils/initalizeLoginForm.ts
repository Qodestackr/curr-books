import { FormGroup, FormControl, Validators } from '@angular/forms';

export function initializeForm(formGroup: FormGroup, ctx: any): void {
  ctx.formGroup = new FormGroup(
    {
      email: new FormControl('', [Validators.required, Validators.email]),
      newPassword: new FormControl('', [
        Validators.required,
        Validators.minLength(8),
      ]),
      confirmPassword: new FormControl('', [
        Validators.required,
        Validators.minLength(8),
      ]),
      securityAnswer: new FormControl('', [
        Validators.required,
        Validators.minLength(6),
      ]),
      userIdOrEmail: new FormControl('', [
        Validators.required,
        Validators.pattern(/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/),
      ]),
      initialPassword: new FormControl('', [Validators.required]),
      OTPVerificationCode: new FormControl('', [
        Validators.required,
        Validators.pattern(/^\d{6}$/),
      ]),
    },
    { validators: ctx.passwordMatchValidator }
  );
}
