import { Component } from '@angular/core';

@Component({
  selector: 'app-test-dashboard',
  templateUrl: './test-dashboard.component.html',
})
export class TestDashboardComponent {

}
