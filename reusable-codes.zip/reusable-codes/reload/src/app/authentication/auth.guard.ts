import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { Select, Store } from '@ngxs/store';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';

import { AuthState } from '../ngxs/state';
import { Logout } from '../ngxs/auth.actions';

// @Injectable({
//   providedIn: 'root',
// })
// export class AuthGuard implements CanActivate {
// @Select(AuthState.isAuthenticated) isAuthenticated$: Observable<boolean>;

// constructor(private store: Store, private router: Router) {}

// canActivate(): Observable<boolean> {
//   return this.isAuthenticated$.pipe(
//     tap((isAuthenticated) => {
//       if (!isAuthenticated) {
//         this.store.dispatch(new Logout());
//         this.router.navigate(['/login']);
//       }
//     })
//   );
// }
// }
