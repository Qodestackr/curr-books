import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';

import { AngularFireAuth } from '@angular/fire/compat/auth';
import {
  GoogleAuthProvider,
  FacebookAuthProvider,
  OAuthProvider,
} from 'firebase/auth';
import { Router } from '@angular/router';

import {
  LOGIN_URL,
  SOCIAL_AUTH_URL,
  FORGOT_PASSWORD_URL,
  VERIFY_ACCOUNT_URL,
  GET_QUESTIONS_URL,
  ANSWER_QUESTION_URL,
  SET_QUESTION_URL,
  RESET_PASSWORD_URL,
  FIRST_TIME_VERIFICATION_URL,
  RESET_USER_ID_URL,
} from './API';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  userData: any; // Save logged in user data
  isFirstTimeLogin: boolean = false;

  constructor(
    private http: HttpClient,
    public afAuth: AngularFireAuth,
    public router: Router
  ) {
    this.afAuth.authState.subscribe((user) => {
      if (user) {
        this.userData = user;
        localStorage.setItem('user', JSON.stringify(this.userData));
        JSON.parse(localStorage.getItem('user')!);
      } else {
        localStorage.setItem('user', 'null');
        JSON.parse(localStorage.getItem('user')!);
      }
    });
  }

  checkFirstTimeLogin(): Observable<boolean> {
    return this.http.get<any>(FIRST_TIME_VERIFICATION_URL).pipe(
      catchError((error) => {
        console.error('Error occurred while checking first-time login:', error);
        return of(false);
      }),
      map((data) => {
        console.log(data, '...API response');
        return data.isFirstTimeLogin ?? false;
      })
    );
  }

  googleLogin() {
    const provider = new GoogleAuthProvider();
    return this.afAuth
      .signInWithPopup(provider)
      .then((result) => {
        console.log('reached', result);
        return result;
      })
      .catch((error) => {
        // Handle error
        console.log(error);
      });
  }

  facebookLogin() /**: Promise<void> */ {
    const provider = new FacebookAuthProvider();
    return this.afAuth
      .signInWithPopup(provider)
      .then((result) => {
        console.log('reached', result);
        return result;
      })
      .catch((error) => {
        // Handle error
        console.log(error);
      });
  }

  microsoftLogin() /**: Promise<void> */ {
    const provider = new OAuthProvider('microsoft.com');
    return this.afAuth
      .signInWithPopup(provider)
      .then((result) => {
        console.log('reached::auth-service.ts', result);
        return result;
      })
      .catch((error) => {
        // Handle error
        console.log(error);
      });
  }

  //Forgot Password
  sendResetPasscode(email: string): Observable<any> {
    const payload = { email: 'mikenzik@gmail.com' }; // hardcoded value @TESTs
    return this.http.post(FORGOT_PASSWORD_URL, payload);
  }

  verifyAccount(passcode: string): Observable<any> {
    const payload = { passcode };
    return this.http.post(VERIFY_ACCOUNT_URL, payload);
  }

  getSecretQuestions(): Observable<any> {
    console.log('Hello FROM: Get Questions');
    return this.http.get(GET_QUESTIONS_URL);
  }

  answerSecretQuestions(answers: any): Observable<any> {
    return this.http.post(ANSWER_QUESTION_URL, answers);
  }

  setSecretQuestions(questions: any): Observable<any> {
    return this.http.post(SET_QUESTION_URL, questions);
  }

  resetUserId(): Observable<any> {
    return this.http.get(RESET_USER_ID_URL);
  }

  login(credentials: any) /**: Observable<any> */ {
    console.log('login endpoint in auth service');
    const requestOptions = {
      method: 'POST',
      headers: this.authHeader(),
    };

    return this.http.post(LOGIN_URL, credentials, requestOptions);
  }

  async resetPassword(newPassword: string) {
    const email = 'kar@gmail.com';

    try {
      const payload = {
        email: email,
        password: '!@#kar,.Qqwuujrjtr', //newPassword,
      };

      const headers = new HttpHeaders(this.authHeader());

      const response = await this.http
        .post(RESET_PASSWORD_URL, payload, { headers: headers })
        .toPromise();

      console.log(response);
      // Handle success case if needed
    } catch (error: any) {
      if (error.error && error.error.errors) {
        const errors = error.error;
        console.log(errors);
        // Handle error case if needed
      } else {
        console.log(error);
      }
    }
  }

  async signOut(): Promise<void> {
    localStorage.removeItem('user');

    try {
      const handleLogout = await this.http.post(`LOGOUT_URL`, {});
      // if handleLogout
      this.router.navigate(['login']);
    } catch (error) {
      console.error('Error occurred during logout:', error);
      this.router.navigate(['login']);
    }
  }

  authHeader() {
    return {
      Accept: 'application/json',
      'Content-Type': 'application/json',
    };
  }
}
