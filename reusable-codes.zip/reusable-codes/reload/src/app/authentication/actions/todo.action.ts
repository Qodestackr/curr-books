import { createAction, props } from '@ngrx/store';

export const addTodo = createAction(
  '[Todo Page] Add Todo',
  props<{ content: string }>
);

export const deleteTodo = createAction(
  '[Todo Page] Remove Todo',
  props<{ id: string }>
);

export const loadTodos = createAction('[Todo Page] Load Todos');

export const loadTodosLoading = createAction('[Todo Page] Load Todos Loading');

export const loadTodosFailed = createAction('[Todo Page] Load Todos Failed');
export const loadTodosSuccess = createAction('[Todo Page] Load Todos Success');
