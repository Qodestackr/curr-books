import { createAction, props } from '@ngrx/store';

// interfaces
import { User } from '../interfaces';

export const login = createAction(
  '[Auth] Login',
  props<{ email: string; password: string }>()
);

export const loginLoading = createAction('[AUTH] Login loading');

export const loginSuccess = createAction(
  '[Auth] Login Success',
  props<{ user: any }>() // User Type
);

export const loginFailure = createAction(
  '[API] Login Failure',
  props<{ message: string; statusCode: string }>()
);

export const setFirstTimeLogin = createAction(
  '[Login] Set First Time Login',
  props<{ isFirstTimeLogin: boolean }>()
);

export const setSelectedEmail = createAction(
  '[Auth] Set Selected Email',
  props<{ item: any }>()
);

export const setUserId = createAction(
  '[Auth] Set User ID',
  props<{ item: any }>()
);

export const socialLogin = createAction(
  '[Auth] Social Login',
  props<{ provider: string }>()
);

// export const firstTimeLogin = createAction('[Auth] First Time Login');

export const logout = createAction('[Auth] Logout');

//userid
export const sendResetUserIdOTP = createAction(
  '[API] Send Reset User ID OTP',
  props<{ email: string }>()
);

export const verifyResetUserIdOTP = createAction(
  '[API] Verify Reset User ID OTP',
  props<{ otp: string }>()
);

export const resetUserId = createAction(
  '[API] Reset User ID',
  props<{ newUserId: string }>()
);

//pwd
export const sendResetPasswordOTP = createAction(
  '[API] Send Reset Password OTP',
  props<{ email: string }>()
);

export const verifySecurityQuestion = createAction(
  '[API] Verify Security Question',
  props<{ securityQuestion: string }>()
);

export const resetPassword = createAction(
  '[API] Reset Password',
  props<{ newPassword: string }>()
);
