const API_BASE_URL = 'https://web.pmsmadeez.com/auth/api';
// const API_BASE_URL = 'http://localhost:9193/auth/api';

export const LOGIN_URL = `${API_BASE_URL}/v1/login`;
export const SOCIAL_AUTH_URL = `${API_BASE_URL}/v1/social-auth`;
export const STORAGE_URL = `https://web.pmsmadeez.com/storage/api/v1/users/4`;
export const FORGOT_PASSWORD_URL = `${API_BASE_URL}/v1/send-reset-passcode`;
export const VERIFY_ACCOUNT_URL = `${API_BASE_URL}/v1/verify-password-reset-passcode`;
export const GET_QUESTIONS_URL = `${API_BASE_URL}/v1/secret-questions`;
export const ANSWER_QUESTION_URL = `${API_BASE_URL}/v1/verify-password-reset-security-questions`;
export const SET_QUESTION_URL = `${API_BASE_URL}/v1/secret-questions`;
export const RESET_PASSWORD_URL = `${API_BASE_URL}/v1/set-password`;
export const FIRST_TIME_VERIFICATION_URL = `${API_BASE_URL}/v1/user-verification`;
export const RESET_USER_ID_URL = `${API_BASE_URL}/v1/reset-user-id`;
