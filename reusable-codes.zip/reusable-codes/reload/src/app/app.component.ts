import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import axios from 'axios';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
})
export class AppComponent {
  title = 'reload';

  ngOnInit(): void {
    // this.testSecretQuestion();
    // this.testLogin();
  }

  constructor(private http: HttpClient) {}

  testSecretQuestion(): void {
    const SECRET_URL = 'https://web.pmsmadeez.com/auth/api/v1/secret-questions';

    this.http.get(SECRET_URL).subscribe(
      (response) => {
        console.log(response);
      },
      (error) => {
        console.log('error');
      }
    );
  }

  testLogin() {
    const LOGIN_URL = 'https://web.pmsmadeez.com/auth/api/v1/login';

    const data = {
      email: 'kar@gmail.com',
      password: 'kar@gmail.com',
    };

    const config = {
      headers: {
        'Content-Type': 'application/json',
      },
      params: {}, // Add any query parameters if needed
    };

    axios
      .post(LOGIN_URL, data, config)
      .then((response) => {
        console.log(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  }
}
