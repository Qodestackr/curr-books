import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {
  LoginFormComponent,
  ResetPasswordFormComponent,
  ResetUseridFormComponent,
  TestDashboardComponent,
} from './authentication/pages';

const routes: Routes = [
  {
    path: 'login',
    pathMatch: 'full',
    component: LoginFormComponent,
  },
  {
    path: 'reset-password',
    pathMatch: 'full',
    component: ResetPasswordFormComponent,
  },
  {
    path: 'reset-userid',
    pathMatch: 'full',
    component: ResetUseridFormComponent,
  },
  {
    path: 'dashboard',
    pathMatch: 'full',
    component: TestDashboardComponent,
  },
  {
    path: '',
    pathMatch: 'full',
    redirectTo: 'dashboard', // can Activate [AuthGuard]
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
