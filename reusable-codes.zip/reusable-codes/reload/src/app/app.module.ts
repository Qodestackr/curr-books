import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { StoreModule } from '@ngrx/store';
import { NgxsModule } from '@ngxs/store';

import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';

import { AngularFireModule } from '@angular/fire/compat';
import { AngularFireAuthModule } from '@angular/fire/compat/auth';

import {
  Firestore,
  getFirestore,
  provideFirestore,
} from '@angular/fire/firestore';

import { firebaseConfig } from 'src/firebase.config';

import { AppComponent } from './app.component';
import { InputComponent } from './authentication/components/input/input.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AuthLayoutComponent } from './authentication/components/auth-layout/auth-layout.component';
import { ButtonComponent } from './authentication/components/button/button.component';
import { SocialButtonComponent } from './authentication/components/social-button/social-button.component';
import { DividerComponent } from './authentication/components/divider/divider.component';
import { SelectInputComponent } from './authentication/components/select-input/select-input.component';
import { FormSecurityQuestionComponent } from './authentication/components/form-security-question/form-security-question.component';
import { OtpFormComponent } from './authentication/components/otp-form/otp-form.component';
import { FormStepLabelComponent } from './authentication/components/form-step-label/form-step-label.component';
import { NotificationComponent } from './authentication/components/notification/notification.component';
import { ConfirmationPopupComponent } from './authentication/components/confirmation-popup/confirmation-popup.component';
import { ResetPasswordFormComponent } from './authentication/pages/reset-password-form/reset-password-form.component';
import { ResetUseridFormComponent } from './authentication/pages/reset-userid-form/reset-userid-form.component';
import { LoginFormComponent } from './authentication/pages/login-form/login-form.component';
import { TestDashboardComponent } from './authentication/pages/test-dashboard/test-dashboard.component';
import { RecoverCredentialsComponent } from './authentication/components/recover-credentials/recover-credentials.component';
import { StepperComponent } from './authentication/components/stepper/stepper.component';

// Service
import { AuthService } from './authentication/auth.service';
import { EffectsModule } from '@ngrx/effects';

import { AuthState } from './ngxs/state';
// import { FirstLoginComponent } from './authentication/pages/first-login/first-login.component';

// import { AuthEffects } from './authentication/reducer/auth.effect';

@NgModule({
  declarations: [
    AppComponent,
    InputComponent,
    AuthLayoutComponent,

    ButtonComponent,
    SocialButtonComponent,
    DividerComponent,
    SelectInputComponent,
    FormSecurityQuestionComponent,
    OtpFormComponent,
    FormStepLabelComponent,
    NotificationComponent,
    ConfirmationPopupComponent,
    ResetPasswordFormComponent,
    ResetUseridFormComponent,
    LoginFormComponent,
    TestDashboardComponent,
    RecoverCredentialsComponent,
    StepperComponent,
    // FirstLoginComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    MatIconModule,

    HttpClientModule,
    // StoreModule.forRoot(authReducer),
    NgxsModule.forRoot([AuthState]),
    // EffectsModule.forRoot([AuthEffects]),
    AngularFireModule.initializeApp(firebaseConfig),
    AngularFireAuthModule,
    provideFirestore(() => {
      let firestore: Firestore;
      firestore = getFirestore();
      return firestore;
    }),
    // TESTS
  ],
  providers: [AuthService],
  bootstrap: [AppComponent],
})
export class AppModule {}
