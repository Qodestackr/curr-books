import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

const routes = [{
        path: '/login',
        name: 'login',
        component: () =>
            import ('../views/Auth/LoginView.vue'),
    }, 
    {
        path: '/forgotten-password',
        name: 'FogottenPassword',
        component: () =>
            import ('../views/Auth/ForgottenPassword.vue'),
    },
    {
        path: '/verify-account',
        name: 'VerifyAccount',
        component: () =>
            import ('../views/Auth/VerifyAccount.vue'),
    },
    {
        path: '/initial-verification',
        name: 'FirstTimeAccountVerification',
        component: () =>
            import ('../views/Auth/FirstAccountVerification.vue'),
    },
    {
        path: '/security-question',
        name: 'SecurityQuestion',
        component: () =>
            import ('../views/Auth/SecurityQuestion.vue'),
    },
    {
        path: '/reset-password',
        name: 'ResetPassword',
        component: () =>
            import ('../views/Auth/ResetPassword.vue'),
    },
    {
        path: '/reset-userid',
        name: 'ResetUserID',
        component: () =>
            import ('../views/Auth/SetUserID.vue'),
    },
    {
        path: '/secret-question',
        name: 'setSecretQuestion',
        component: () =>
            import ('../views/Auth/SetSecretQuestion.vue'),
        props: true,
    },
    // dashboard routes
    {
        path: '/',
        component: () =>
            import ('../components/Layout/LayoutComponent.vue'),
        children: [{
                path: '/',
                name: 'Dashboard',
                component: () =>
                    import ('../views/DashboardView.vue'),
            },

            {
                path: 'files/:orgId?',
                name: 'Files',
                component: () =>
                    import ('../views/Files/ManageFiles.vue'),
                props: true,
            },

            {
                path: 'sign',
                name: 'Signature',
                component: () =>
                    import ('../views/Files/FileAnnotation.vue'),
            },
            {
                path: 'Shared',
                name: 'shared-document',
                component: () =>
                    import ('../views/Files/DocuSign.vue'),
            },

            {
                path: 'share-doc',
                name: 'ShareDocument',
                component: () =>
                    import ('../views/Files/ShareDocument.vue'),
            },

            {
                path: 'subscriber-config/:orgId?',
                name: 'Configuration',
                component: () =>
                    import ('../views/Subscribers/SubscriberConfig.vue'),
                props: true,
            },
        ],
    },
]

const router = new VueRouter({
    routes
})

export default router