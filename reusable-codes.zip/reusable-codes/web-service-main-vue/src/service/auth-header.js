// auth-headers
export default function authHeader() {
    // let token = localStorage.getItem('token')
        return {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
        }
} 