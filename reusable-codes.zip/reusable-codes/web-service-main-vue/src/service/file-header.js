// Data service
export default function fileHeader() {
    // let token = localStorage.getItem("token");
    // if (token) {
    //   return {
    //     Authorization: "Bearer " + token,
    //     Accept: "application/json",
    //     "Content-Type": "multipart/form-data",

    //   };
    // } else {
    //   return {
    //     Accept: "application/json",
    //     "Content-Type": "multipart/form-data",
    //   };
    // }

    return {
        'Accept': "application/json",
        "Content-Type": "multipart/form-data",
    };
}