import axios from 'axios';
import authHeader from './auth-header';

const API_URL = process.env.VUE_APP_API_URL;

class ConfigurationService {
    getConfigurations(orgId) {
        return axios.get(API_URL + 'storage/api/v1/config/' + orgId, { headers: authHeader() })
    }

    getConfiguration(config) {
        return axios.get(API_URL + 'storage/api/v1/config/' + config, { headers: authHeader() })
    }

    storeConfiguration(resource) {
        return axios.post(API_URL + 'storage/api/v1/config', resource, { headers: authHeader() })
    }

    updateConfiguration(resource) {
        return axios.put(API_URL + 'storage/api/v1/config', resource, { headers: authHeader() })
    }

    deleteConfiguration(config) {
        return axios.delete(API_URL + 'storage/api/v1/config/' + config.id, { headers: authHeader() })
    }
}

export default new ConfigurationService();