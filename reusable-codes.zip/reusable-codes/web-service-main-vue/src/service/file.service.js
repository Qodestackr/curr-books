// Data sevice
import axios from 'axios'
import authHeader from './auth-header'
import fileHeader from './file-header';

const API_URL = process.env.VUE_APP_API_URL;



class FileService {
    getUserFiles(id) {
        return axios.get(API_URL + 'storage/api/v1/files/' + id, { headers: authHeader() });
    }

    uploadFile(resource) {
        return axios.post(API_URL + "storage/api/v1/files/upload", resource, { headers: fileHeader() });
    }

    updateFile(resource) {
        return axios.put(API_URL + "storage/api/v1/files/upload", resource, { headers: authHeader() });
    }

    deleteFile(file) {
        return axios.delete(API_URL + "storage/api/v1/delete/" + file.id, { headers: authHeader() });
    }

    addSignatureMails(resource) {
        return axios.post(API_URL + "docusign/api/v1/createEmbeddedRequestUrl", resource, { headers: authHeader() });
    }

    // annotations
    addAnnotations(resource) {
        return axios.put(API_URL + "docusign/lease/" + resource.prospectEmail, resource, { headers: authHeader() });
    }

    getDocuSign(id) {
        return axios.get(API_URL + "docusign/lease/" + id, { headers: authHeader() });
    }

}

export default new FileService()