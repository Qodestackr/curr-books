// Data sevice
import axios from 'axios'
import authHeader from './auth-header'

const API_URL = process.env.VUE_APP_API_URL;

class UserService {

    index() {
        return axios.get(API_URL + 'storage/api/v1/users/4', { headers: authHeader() })
    }
 
    forgotPassword(user) {
        return axios.post(API_URL + 'auth/api/v1/send-reset-passcode', user, { headers: authHeader() })
    }

    verifyAccount(code){
        return axios.post(API_URL + 'auth/api/v1/verify-password-reset-passcode', code, { headers: authHeader() })
    }

    getQuestions(){
        return axios.get(API_URL + 'auth/api/v1/secret-questions', {headers: authHeader()})
    }

    answerQuestion(item){
        return axios.post(API_URL + 'auth/api/v1/verify-password-reset-security-questions', item, { headers: authHeader() })
    }

    setQuestion(item){
        return axios.post(API_URL + 'auth/api/v1/secret-questions', item, { headers: authHeader() })
    }

    resetPassword(item){
        return axios.post(API_URL + 'auth/api/v1/set-password', item, { headers: authHeader() });
    }

    firstTimeVerification(code){
        return axios.post(API_URL + 'auth/api/v1/user-verification', code, { headers: authHeader() })
    }

    resetUserId(item){
        return axios.post(API_URL + 'auth/api/v1/reset-user-id', item, { headers: authHeader() })
    }
    
    socialAuth(token){
        return axios.post(API_URL + 'auth/api/v1/social-auth', token, { headers: authHeader() })
    }

    login(user) {
        return axios.post(API_URL + 'auth/api/v1/login', {
            email: user.email,
            password: user.password
        }).then(Response => {
            return Response
        });
    }
}

export default new UserService()