// Data sevice
import axios from 'axios'
import authHeader from './auth-header'

const API_URL = process.env.VUE_APP_API_URL;

class SubscriberService {

    getConfigurations() {
        return axios.get(API_URL + 'storage/api/v1/config', { headers: authHeader() })
    }

}

export default new SubscriberService()