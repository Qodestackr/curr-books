<template>
  <v-app>
    <v-main>
      <router-view />
      <Alert/>
      <!-- <SnackBar/> -->
    </v-main>
  </v-app>
</template>
<style>
th {
  font-size: 14px !important;
  text-transform: uppercase;
}
</style>
<script>
import Alert from "@/components/AlertBar.vue";
// import SnackBar from "@/components/SnackBar.vue";

export default {
  name: "App",
  components: { Alert, 
  // SnackBar 
  },

  data: () => ({
    //
  }),
};
</script>
<style>
v-app {
  font-family: 'FF Neuwelt' !important;
  src: url('./fonts/FF Neuwelt/Neuwelt-Regular.ttf');
  font-weight: 900;
  font-style: normal;
}
</style>


