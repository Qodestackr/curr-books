<template>
	<div>
		<v-app id="inspire">
			<v-layout row wrap>
				<!-- Art Work -->
				<v-flex xs12 sm12 md6 class="blue lighten-5">
					<v-img
						height="100vh"
						src="../../assets/images/Question_Frame.png"
					>
					</v-img>
				</v-flex>

				<!-- Login Form -->
				<v-flex sm12x s12 sm12 md6 class="my-9">
					<v-card
						light
						outlined
						color="transparent"
						class="mx-auto"
						max-width="455px"
					>
						<div class="mb-15 ml-7">
							<v-img
								max-height="100"
								max-width="100"
								src="../../assets/favicon.png"
							></v-img>
						</div>
						<v-card-title>
							<div
								style="font-size: 25px"
								class="mt-15 font-weight-bold heading-1"
							>
								Security question: protected<br />
								and unique.
							</div>
							<div class="mt-1 font-weight-light subtitle-2">
								Choose your own unique security question and
								submit the <br />
								answer you have informed us.s
							</div>
						</v-card-title>
						<v-card-text>
							<v-form
								ref="form"
								v-model="valid"
								lazy-validation
								class="mt-n2s"
							>
								<v-flex xs1>
									<v-subheader
										class="ml-n4 mb-n2 caption font-weight-bold text-no-wrap"
										>choose your security
										question</v-subheader
									>
								</v-flex>
								<v-autocomplete
									v-model="editedItem.questionId"
									:items="questions"
									color="primary"
									:rules="rules.select"
									item-value="questionId"
									item-text="question"
									placeholder="your first pet name"
									outlined
									dense
								></v-autocomplete>
								<v-flex xs1>
									<v-subheader
										class="ml-n4 mt-n7 caption font-weight-bold text-no-wrap"
										>Answer</v-subheader
									>
								</v-flex>
								<v-text-field
									v-model="editedItem.answer"
									:rules="rules.required"
									color="primary"
									dense
									outlined
									class="mt-n3"
									placeholder="write your answer"
								></v-text-field>
							</v-form>
							<v-btn
								large
								min-width="0"
								class="mt-2"
								color="primary"
								@click="setQuestionAnswer"
							>
								Verify
							</v-btn>
						</v-card-text>
					</v-card>
				</v-flex>
				<v-snackbar
					v-model="errorSnackbar"
					:timeout="timeout"
					:value="true"
					:icon="icon"
					absolute
					bottom
					color="error"
					outlined
					right
					class="mb-5 mr-10"
				>
					<v-icon color="error">mdi-close-circle</v-icon>
					{{ message }}
				</v-snackbar>
				<v-snackbar
					v-model="successSnackbar"
					:timeout="timeout"
					:value="true"
					absolute
					bottom
					color="success"
					outlined
					right
					class="mb-5 mr-10"
				>
					<v-icon color="success">mdi-check-circle</v-icon>
					{{ message }}
				</v-snackbar>
				<v-snackbar
					v-model="infoSnackbar"
					:timeout="timeout"
					:value="true"
					absolute
					bottom
					color="info"
					outlined
					right
					class="mb-5 mr-10"
				>
					<v-icon color="info">mdi-information</v-icon>
					{{ message }}
				</v-snackbar>
			</v-layout>
		</v-app>
	</div>
</template>

<script>
import User from "@/model/user";
import UserService from "@/service/user.service";

export default {
	data: () => ({
		message: "",
		infoSnackbar: false,
		successSnackbar: false,
		errorSnackbar: false,
		timeout: 3000,
		valid: true,
		user: new User("", ""),
		loading: true,
		passwordRules: [
			(v) => !!v || "Password is required",
			(v) => (v && v.length >= 3) || "Min 8 characters",
		],
		emailRules: [
			(v) => !!v || "E-mail is required",
			(v) => /.+@.+\..+/.test(v) || "E-mail must be valid",
			(v) => (v && v.length >= 3) || "Min 3 characters",
		],
		rules: {
			select: [(v) => !!v || "An item should be selected"],
			select2: [
				(v) => v.length > 0 || "At least one item should be selected",
			],
			required: [
				(v) => !!v || "Field is required",
				(v) => (v && v.length >= 3) || "Min 3 characters",
			],
			textArea: [
				(v) => !!v || "Field is required",
				(v) =>
					(v && v.length >= 3 && v.length <= 160) ||
					"Min 3 and Max 160 characters",
			],
		},
		questions: [],
		currentYear: new Date().getFullYear(),
		editedItem: {
			questionId: "",
			userId: "",
			answer: "",
		},
	}),
	computed: {
		validation() {
			return this.$store.state.validationErrors;
		},
		loggedIn() {
			return this.$store.state.auth.status.loggedIn;
		},
		selectedEmail() {
			return this.$store.state.auth.selected_email;
		},
	},
	created() {
		this.getQuestions();
	},

	methods: {
		// Validate Form Imputs
		validate() {
			return this.$refs.form.validate();
		},

		// get Questions
		getQuestions() {
			return UserService.getQuestions().then(
				(response) => {
					if (response.status == 200) {
						this.questions = response.data.data;
						this.loading = false;
					} else {
						this.questions = [];
						this.loading = false;
						console.log(response.data.console.error);
					}
				},
				(error) => {
					this.questions = [];
					console.log(error);
				}
			);
		},

		// verifyQuestionAnswer
		setQuestionAnswer() {
			this.valid = this.validate();
			this.editedItem.emailId = this.selectedEmail;
			UserService.setQuestion(this.editedItem).then(
				(response) => {
					if (response.data.statusCode == "AUTH003") {
						this.successSnackbar = true;
						this.message = response.data.message;
						this.loading = false;
						this.$router.push("/reset-password");
					} else {
						this.loading = false;
						this.errorSnackbar = true;
						this.message = response.data.message;
						if (response.response && response.response.data) {
							this.errorSnackbar = true;
							this.message = response.data.message;
						}
					}
				},
				(error) => {
					// this.$store.dispatch("setLoading", false);
					this.errorSnackbar = true;
					this.message =
						error.message ||
						"Something went wrong please try again";
				}
			);
		},
	},
};
</script>
