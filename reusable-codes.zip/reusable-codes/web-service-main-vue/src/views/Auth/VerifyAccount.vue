<template>
	<div>
		<v-app id="inspire">
			<v-layout row wrap>
				<!-- Art Work -->
				<v-flex xs12 sm12 md6 class="blue lighten-5">
					<v-img
						height="100vh"
						src="../../assets/images/OTP_Frame.png"
					>
					</v-img>
				</v-flex>

				<!-- Login Form -->
				<v-flex sm12x s12 sm12 md6 class="my-9">
					<v-card
						light
						outlined
						color="transparent"
						class="mx-auto"
						max-width="455px"
					>
						<v-card-title class="mt-n2">
							<div class="mb-15">
								<v-img
									max-height="100"
									max-width="100"
									src="../../assets/favicon.png"
								></v-img>
							</div>

							<div style="position: absolute" class="my-15 h1">
								Check your Mail
							</div>

							<div class="mt-15 caption">
								We just send an email with password reset
								instruction to<br />
								email address which is associated with the user
								Id:
							</div>
							<div class="mt-10 caption font-weight-bold">
								Please enter the 6 digit code that was send to
								you via mail.
							</div>
							<div class="caption">
								{{ selectedEmail }}<v-icon x-small
									>mdi-pencil</v-icon
								>
							</div>
						</v-card-title>
						<v-card-text>
							<v-form ref="form" v-model="valid" lazy-validation>
								<v-otp-input
									v-model="editedItem.passcode"
									length="6"
									small
									:rules="required"
									number
								></v-otp-input>
							</v-form>
							<div class="mt-1 caption">
								Didn't recieve an email? 05:00.
							</div>
							<v-btn
								large
								min-width="0"
								class="mt-7"
								color="primary"
								@click="handleOTP"
							>
								Verify
							</v-btn>
						</v-card-text>
					</v-card>
				</v-flex>
			</v-layout>
			<v-snackbar
				v-model="errorSnackbar"
				:timeout="timeout"
				:value="true"
				absolute
				bottom
				color="error"
				outlined
				right
				class="mb-5 mr-10"
			>
				<v-icon color="error">mdi-close-circle</v-icon>
				{{ message }}
			</v-snackbar>
			<v-snackbar
				v-model="successSnackbar"
				:timeout="timeout"
				:value="true"
				absolute
				bottom
				color="success"
				outlined
				right
				class="mb-5 mr-10"
			>
				<v-icon color="success">mdi-check-circle</v-icon>
				{{ message }}
			</v-snackbar>
			<v-snackbar
				v-model="infoSnackbar"
				:timeout="timeout"
				:value="true"
				absolute
				bottom
				color="info"
				outlined
				right
				class="mb-5 mr-10"
			>
				<v-icon color="info">mdi-information</v-icon>
				{{ message }}
			</v-snackbar>
		</v-app>
	</div>
</template>

<script>
import User from "@/model/user";
import UserService from "@/service/user.service";

export default {
	data: () => ({
		message: "",
		infoSnackbar: false,
		successSnackbar: false,
		errorSnackbar: false,
		timeout: 3000,
		valid: true,
		user: new User("", ""),
		passwordRules: [
			(v) => !!v || "Password is required",
			(v) => (v && v.length >= 3) || "Min 8 characters",
		],
		emailRules: [
			(v) => !!v || "E-mail is required",
			(v) => /.+@.+\..+/.test(v) || "E-mail must be valid",
			(v) => (v && v.length >= 3) || "Min 3 characters",
		],
		currentYear: new Date().getFullYear(),
		editedItem: {
			passcode: "",
			email: "",
		},
	}),
	computed: {
		validation() {
			return this.$store.state.validationErrors;
		},
		loggedIn() {
			return this.$store.state.auth.status.loggedIn;
		},
		loading() {
			return this.$store.state.loading;
		},
		selectedEmail() {
			return this.$store.state.auth.selected_email;
		},
	},

	methods: {
		// Validate Form Imputs
		validate() {
			return this.$refs.form.validate();
		},

		// forgtten password Method
		handleOTP() {
			this.valid = this.validate();
			this.$store.dispatch("setLoading", true);
			this.editedItem.email = this.selectedEmail;
			UserService.verifyAccount(this.editedItem).then(
				(response) => {
					if (
						response.status == 200 &&
						response.data.statusCode === "AUTH003"
					) {
						//   this.$store.dispatch("setLoading", false);
						this.successSnackbar = true;
						this.message = response.data.message;
						this.$router.push("/security-question");
					} else {
						this.errorSnackbar = true;
						this.message = response.data.message;
						//   this.$store.dispatch("setLoading", false);
						if (response.response && response.response.data) {
							this.errorSnackbar = true;
							this.message = response.data.message;
						}
					}
				},
				(error) => {
					this.$store.dispatch("setLoading", false);
					this.errorSnackbar = true;
					this.message = error.message || 'Something went wrong, please try again';
				}
			);
		},
	},
};
</script>
<style>
