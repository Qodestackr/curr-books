<template>
	<div>
		<v-app id="inspire">
			<v-layout row wrap>
				<!-- Art Work -->
				<v-flex xs12 sm12 md6 class="blue lighten-5">
					<v-img
						height="100vh"
						src="../../assets/images/Forgotten_Frame.png"
					>
					</v-img>
				</v-flex>

				<!-- Login Form -->
				<v-flex sm12x s12 sm12 md6 class="my-9">
					<v-card
						light
						outlined
						color="transparent"
						class="mx-auto"
						max-width="455px"
					>
						<div class="mb-5 mt-10 ml-4 d-flex">
							<v-img
								max-height="100"
								max-width="100"
								src="../../assets/favicon.png"
							></v-img>
						</div>
						<v-card-title class="mt-10">
							<div class="mt-15 font-weight-bold heading-1">
								Reset Your Password/User Id
							</div>
							<div class="mt-1 font-weight-light subtitle-2">
								Please Enter the User ID/email Address that<br />
								is Linked with your account.
							</div>
						</v-card-title>
						<v-card-text>
							<v-form
								ref="form"
								v-model="valid"
								lazy-validation
								class="mt-2"
							>
								<v-flex xs1>
									<v-subheader
										class="ml-n4 mb-n2 caption font-weight-bold text-no-wrap"
										>Email/ User Id</v-subheader
									>
								</v-flex>
								<v-text-field
									v-model="user.email"
									dense
									color="primary"
									label=""
									:rules="required"
									outlined
									required
									placeholder="email/userId"
								></v-text-field>
							</v-form>
							<v-btn
								large
								block
								min-width="0"
								class="mt-5"
								color="primary"
								@click="handleForgotPassword"
							>
								Send email
							</v-btn>
						</v-card-text>
					</v-card>
				</v-flex>
				<v-snackbar
					v-model="errorSnackbar"
					:timeout="timeout"
					:value="true"
					absolute
					bottom
					color="error"
					outlined
					right
					class="mb-5 mr-10"
				>
					<v-icon color="error">mdi-close-circle</v-icon>
					{{ message }}
				</v-snackbar>
				<v-snackbar
					v-model="successSnackbar"
					:timeout="timeout"
					:value="true"
					absolute
					bottom
					color="success"
					outlined
					right
					class="mb-5 mr-10"
				>
					<v-icon color="success">mdi-check-circle</v-icon>
					{{ message }}
				</v-snackbar>
				<v-snackbar
					v-model="infoSnackbar"
					:timeout="timeout"
					:value="true"
					absolute
					bottom
					color="info"
					outlined
					right
					class="mb-5 mr-10"
				>
					<v-icon color="info">mdi-information</v-icon>
					{{ message }}
				</v-snackbar>
			</v-layout>
		</v-app>
	</div>
</template>

<script>
import User from "@/model/user";
import UserService from "@/service/user.service";

export default {
	data: () => ({
		message: "",
		infoSnackbar: false,
		successSnackbar: false,
		resetUserId: 1,
		errorSnackbar: false,
		timeout: 3000,
		valid: true,
		showPassword: false,
		user: new User("", ""),
		passwordRules: [
			(v) => !!v || "Password is required",
			(v) => (v && v.length >= 3) || "Min 8 characters",
		],
		emailRules: [
			(v) => !!v || "E-mail is required",
			(v) => /.+@.+\..+/.test(v) || "E-mail must be valid",
			(v) => (v && v.length >= 3) || "Min 3 characters",
		],
      required: [
        (v) => !!v || "email/userId is required",
        (v) => (v && v.length >= 1) || "Min 1 characters",
      ],
		currentYear: new Date().getFullYear(),
	}),
	computed: {
		validation() {
			return this.$store.state.validationErrors;
		},
		loggedIn() {
			return this.$store.state.auth.status.loggedIn;
		},
		loading() {
			return this.$store.state.loading;
		},
	},

	methods: {
		// Validate Form Imputs
		validate() {
			return this.$refs.form.validate();
		},

		// forgtten password Method
		handleForgotPassword() {
			this.valid = this.validate();
			this.$store.dispatch("setLoading", true);
			UserService.forgotPassword(this.user.email).then(
				(response) => {
					if (
						response.status &&
						response.data.statusCode === "AUTH003"
					) {
						//   this.$store.dispatch("setLoading", false);
						this.$store.dispatch(
							"auth/setSelectedEmail",
							this.user.email
						);
						this.successSnackbar = true;
						this.message = response.data.message;
						this.$router.push("/verify-account");
					} else {
						this.errorSnackbar = true;
						this.message = response.data.message;
						//   this.$store.dispatch("setLoading", false);
						if (response.response && response.response.data) {
							this.errorSnackbar = true;
							this.message = response.data.message;
						}
					}
				},
				(error) => {
					this.$store.dispatch("setLoading", false);
					this.errorSnackbar = true;
					this.message = error.message || 'something went wrong, please try again';
				}
			);
		},
	},
};
</script>
<style>
