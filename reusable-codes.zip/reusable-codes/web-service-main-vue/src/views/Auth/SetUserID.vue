<template>
	<div>
		<v-app id="inspire">
			<v-layout row wrap>
				<!-- Art Work -->
				<v-flex xs12 sm12 md6 class="blue lighten-5">
					<v-img
						height="100vh"
						src="../../assets/images/userId.png"
					>
					</v-img>
				</v-flex>

				<!-- Login Form -->
				<v-flex sm12x s12 sm12 md6 class="my-9">
					<v-card
						light
						outlined
						color="transparent"
						class="mx-auto"
						max-width="455px"
					>
						<div class="mb-15 ml-7">
							<v-img
								max-height="100"
								max-width="100"
								src="../../assets/favicon.png"
							></v-img>
						</div>
						<v-card-title class="mt-n2">
							<div
								style="font-size: 25px"
								class="mt-15 font-weight-bold heading-1"
							>
								Change your UserId
							</div>
							<div class="mt-1 font-weight-light subtitle-2">
								Create user id that is easy to remember and
								<br />hard for others to guess.
							</div>
						</v-card-title>
						<v-card-text>
							<v-form
								ref="form"
								v-model="valid"
								lazy-validation
								class="mt-2"
							>
								<v-flex xs1>
									<v-subheader
										class="ml-n4 mt-5 caption font-weight-bold text-no-wrap"
										>New UserId</v-subheader
									>
								</v-flex>
								<v-text-field
									v-model="editedItem.userId"
									:rules="rules.required"
									color="primary"
									dense
									outlined
									class="mt-n"
								
								></v-text-field>
							</v-form>
							<v-btn
								large
								min-width="0"
								class="mt-2"
								color="primary"
								@click="resetUserId"
							>
								Reset userId	
							</v-btn>
						</v-card-text>
					</v-card>
				</v-flex>
				<v-snackbar
					v-model="errorSnackbar"
					:timeout="timeout"
					:value="true"
					absolute
					bottom
					color="error"
					outlined
					right
					class="mb-5 mr-10"
				>
					<v-icon color="error">mdi-close-circle</v-icon>
					{{ message }}
				</v-snackbar>
				<v-snackbar
					v-model="successSnackbar"
					:timeout="timeout"
					:value="true"
					absolute
					bottom
					color="success"
					outlined
					right
					class="mb-5 mr-10"
				>
					<v-icon color="success">mdi-check-circle</v-icon>
					{{ message }}
				</v-snackbar>
				<v-snackbar
					v-model="infoSnackbar"
					:timeout="timeout"
					:value="true"
					absolute
					bottom
					color="info"
					outlined
					right
					class="mb-5 mr-10"
				>
					<v-icon color="info">mdi-information</v-icon>
					{{ message }}
				</v-snackbar>
			</v-layout>
		</v-app>
	</div>
</template>

<script>
import User from "@/model/user";
import UserService from "@/service/user.service";

export default {
	data: () => ({
		message: "",
		showPassword: false,
		showConfPassword: false,
		infoSnackbar: false,
		successSnackbar: false,
		errorSnackbar: false,
		timeout: 3000,
		valid: true,
		user: new User("", ""),
		loading: true,
		passwordRules: [
			(v) => !!v || "Password is required",
			(v) => (v && v.length >= 8) || "Min 8 characters",
			(v) => (v && /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{6,}$/.test(v)) || 'Minimum 8 characters, One capital latter, Special charater, Number',
		],
		emailRules: [
			(v) => !!v || "E-mail is required",
			(v) => /.+@.+\..+/.test(v) || "E-mail must be valid",
			(v) => (v && v.length >= 3) || "Min 3 characters",
		],
		rules: {
			select: [(v) => !!v || "An item should be selected"],
			select2: [
				(v) => v.length > 0 || "At least one item should be selected",
			],
			required: [
				(v) => !!v || "Field is required",
				(v) => (v && v.length >= 3) || "Min 3 characters",
			],
			textArea: [
				(v) => !!v || "Field is required",
				(v) =>
					(v && v.length >= 3 && v.length <= 160) ||
					"Min 3 and Max 160 characters",
			],
		},
		questions: [],
		currentYear: new Date().getFullYear(),

		editedItem: {
			userId: "",
			emailId: "",
		},
	}),
	computed: {
		validation() {
			return this.$store.state.validationErrors;
		},
		loggedIn() {
			return this.$store.state.auth.status.loggedIn;
		},
		selectedEmail() {
			return this.$store.state.auth.selected_email;
		},

		confirmPasswordRules() {
			return [
				(value) => !!value || "Confirm Password is required",
				(value) =>
					value === this.editedItem.password ||
					"Passwords do not match",
			];
		},
	},

	methods: {
		// Validate Form Imputs
		validate() {
			return this.$refs.form.validate();
		},

		// reset password
		resetUserId() {
			this.valid = this.validate();
			this.editedItem.emailId = this.selectedEmail;
			UserService.resetUserId(this.editedItem).then(
				(response) => {
					console.log("res", response);
					if (response.data.statusCode === "AUTH003") {
						this.successSnackbar = true;
						this.message = response.data.message;
						this.loading = false;
						this.$router.push("/login");
					} else {
						console.log(response, "34");
						this.loading = false;
						this.errorSnackbar = true;
						this.message = response.data.message;
						if (response && response.message) {
							this.errorSnackbar = true;
							this.message = response.data.message;
						}
					}
				},
				(error) => {
					// this.$store.dispatch("setLoading", false);
					this.errorSnackbar = true;
					this.message =
						error.message ||
						"something went wrong, please try again.s";
				}
			);
		},
	},
};
</script>
