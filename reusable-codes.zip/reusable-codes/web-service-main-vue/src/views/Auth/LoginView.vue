<template>
	<div>
		<v-app id="inspire">
			<v-layout row wrap>
				<!-- Art Work -->
				<v-flex xs12 sm12 md6 class="blue lighten-5">
					<v-img
						height="100vh"
						src="../../assets/images/Framesvg.svg"
					>
						<div
							class="d-flex pa-4"
							style="
								font-size: 33px;
								font-weight: bold;
								color: #2269a1;
								position: absolute;
								top: 3%;
								left: 16%;
							"
						>
							INTELLIGENT FINANCIAL MANAGEMENT TOOLS FOR LANDLORDS
						</div>
					</v-img>
				</v-flex>

				<!-- Login Form -->
				<v-flex sm12x s12 sm12 md6 class="my-auto">
					<v-card
						light
						outlined
						color="transparent"
						class="mx-auto"
						max-width="455px"
					>
						<div class="mb-5 mt-n10 ml-4 d-flex">
							<v-img
								max-height="100"
								max-width="100"
								src="../../assets/favicon.png"
							></v-img>
						</div>
						<v-card-title class="mt-n2 mx-auto">
							<div class="mb-10 font-weight-bold heading-1">
								Welcome Back to Reload
							</div>
							<div class="mt-n15 font-weight-thin caption">
								Logging in to Reload to continue Managing <br />
								Your Tenants Wisely.
							</div>

							<div class="mt-4 mb-2 caption font-weight-medium">
								Enter your credentials to access your account
							</div>
							<div>
								<v-btn
									class=""
									outlined
									color="grey"
									@click="loginWithGoogle"
								>
									<v-img
										class="mx-1"
										src="../../assets/Google.svg.png"
										max-height="25"
										max-width="25"
									></v-img>
									<span class="text-capitalize">Google</span>
								</v-btn>
								<v-btn
									class="ml-1"
									outlined
									color="grey"
									@click="loginWithFacebook"
								>
									<v-img
										class="mx-1"
										src="../../assets/Facebook.svg.png"
										max-height="25"
										max-width="25"
									></v-img>
									<span class="text-capitalize"
										>Facebook</span
									>
								</v-btn>
								<v-btn
									class="ml-1"
									outlined
									color="grey"
									@click="loginWithMicrosoft"
								>
									<v-img
										class="mx-1"
										src="../../assets/Microsoft.jpeg"
										max-height="17"
										max-width="26"
									></v-img>
									<span class="text-capitalize"
										>Microsoft</span
									>
								</v-btn>
							</div>
						</v-card-title>
						<v-card-text>
							<v-row wrap no-gutters align="center" class="my-2">
								<v-divider class="mr-1" />OR<v-divider
									class="ml-1"
								/>
							</v-row>
							<v-form ref="form" v-model="valid" lazy-validation>
								<v-flex xs1>
									<v-subheader
										class="ml-n4 mb-n2 caption font-weight-bold text-no-wrap"
										>User Id / Email Id</v-subheader
									>
								</v-flex>
								<v-text-field
									v-model="user.email"
									dense
									color="primary"
									append-icon="mdi-account-outline"
									label=""
									:rules="required"
									outlined
									required
									placeholder=" "
								></v-text-field>
								<v-flex xs1>
									<v-subheader
										class="ml-n4 mt-n6 mb-n2 caption font-weight-bold"
										>Password</v-subheader
									>
								</v-flex>
								<v-text-field
									v-model="user.password"
									:append-icon="
										showPassword ? 'mdi-eye' : 'mdi-eye-off'
									"
									:type="showPassword ? 'text' : 'password'"
									dense
									color="primary"
									name="input-10-1"
									label=""
									:rules="passwordRules"
									hint="At least 8 characters"
									outlined
									@click:append="showPassword = !showPassword"
								></v-text-field>
							</v-form>
							<div>
								<v-btn
									text
									color="primary"
									class="ml-n4 mt-n7"
									@click="goToForgotPassword"
									><span
										class="text-capitalize"
										style="font-size: 11px"
										>Forgot password?</span
									></v-btn
								>
							</div>
							<div>
								<v-btn text color="primary" class="ml-n4 mt-n7" @click="goToForgotUserId"
									><span
										class="text-capitalize"
										style="font-size: 11px"
										>Forgot your User Id?</span
									></v-btn
								>
							</div>
							<v-btn
								large
								block
								min-width="0"
								color="primary"
								@click="handleLogin"
							>
								Sign in
							</v-btn>
						</v-card-text>
					</v-card>
				</v-flex>
				<v-snackbar
					v-model="errorSnackbar"
					:timeout="timeout"
					:value="true"
					absolute
					bottom
					color="error"
					outlined
					right
					class="mb-5 mr-10"
				>
					<v-icon color="error">mdi-close-circle</v-icon>
					{{ message }}
				</v-snackbar>
				<v-snackbar
					v-model="successSnackbar"
					:timeout="timeout"
					:value="true"
					absolute
					bottom
					color="success"
					outlined
					right
					class="mb-5 mr-10"
				>
					<v-icon color="success">mdi-check-circle</v-icon>
					{{ message }}
				</v-snackbar>
				<v-snackbar
					v-model="infoSnackbar"
					:timeout="timeout"
					:value="true"
					absolute
					bottom
					color="info"
					outlined
					right
					class="mb-5 mr-10"
				>
					<v-icon color="info">mdi-information</v-icon>
					{{ message }}
				</v-snackbar>
			</v-layout>
		</v-app>
	</div>
</template>

<script>
import axios from "axios";
import User from "@/model/user";
import * as firebase from "firebase/auth";
import UserService from "@/service/user.service";

export default {
	data: () => ({
		valid: true,
		showPassword: false,
		message: "",
		resetUserId: 0,
		infoSnackbar: false,
		successSnackbar: false,
		errorSnackbar: false,
		timeout: 3000,
		user: new User("", ""),
		passwordRules: [
			(v) => !!v || "Password is required",
			(v) => (v && v.length >= 3) || "Min 8 characters",
		],
		emailRules: [
			(v) => !!v || "E-mail is required",
			(v) => /.+@.+\..+/.test(v) || "E-mail must be valid",
			(v) => (v && v.length >= 3) || "Min 3 characters",
		],
      required: [
        (v) => !!v || "E-mail/userId is required",
        (v) => (v && v.length >= 1) || "Min 1 characters",
      ],
		currentYear: new Date().getFullYear(),

		editedItem: {
			token: "",
		},
	}),

	computed: {
		validation() {
			return this.$store.state.validationErrors;
		},
		loggedIn() {
			return this.$store.state.auth.status.loggedIn;
		},
		loading() {
			return this.$store.state.loading;
		},
	},

	created() {
		this.getValidationErrors();
	},
	methods: {
		// Validate Form Imputs
		validate() {
			return this.$refs.form.validate();
		},

		// getting Validations Error # intercepting the response
		getValidationErrors() {
			axios.interceptors.response.use(
				(res) => {
					this.$store.dispatch("setValidationErrors", []);
					return res;
				},
				(error) => {
					this.$store.dispatch("setValidationErrors", error.message);
					return error;
				}
			);
		},

		// redirect to forgot password
		goToForgotPassword() {
			this.$router.push("/forgotten-password");
			this.$store.dispatch("auth/setuserId", 0);
		},

		goToForgotUserId() {	
			this.resetUserId = 1;
			this.$router.push("/forgotten-password");
			this.$store.dispatch("auth/setuserId", this.resetUserId);
		},

		

		// Login Method
		handleLogin() {
			this.valid = this.validate();
			if (this.valid && this.user.email && this.user.password) {
				// this.$store.dispatch("setLoading", true);
				return UserService.login(this.user).then(
					(response) => {
						if (response.data.statusCode === "AUTH003") {
							setTimeout(() => {
								this.successSnackbar = true;
								this.message = response.data.message;
								this.$router.push(
									this.$route.query.redirect || "/"
								);
							}, 1500);
						} else {
							if (response.data.statusCode === "AUTH007") {
								this.successSnackbar = true;
								this.message = response.data.message;
								this.$store.dispatch(
									"auth/setSelectedEmail",
									this.user.email
								);
								this.$router.push("/initial-verification");
							}
							// this.$store.dispatch("setLoading", false);
							if (response.data.message) {
								this.errorSnackbar = true;
								this.message = response.data.message;
							} else {
								this.errorSnackbar = true;
								this.message =
									"Something went wrong, please try again!";
							}
						}
					},
					(error) => {
						console.log("err", error);
						// this.$store.dispatch("setLoading", false);
						this.errorSnackbar = true;
						this.message =
							error.message ||
							"Something went wrong, please try again!";
					}
				);
			}
		},

		// social Authentication
		loginWithGoogle() {
			const provider = new firebase.GoogleAuthProvider();
			firebase
				.signInWithPopup(firebase.getAuth(), provider)
				.then((user) => {
					this.editedItem.token = user.user.accessToken;
					this.socialAuth(this.editedItem);
				})
				.catch((error) => {
					this.errorSnackbar = true;
					this.message =
						error.message ||
						"Somethting went wrong, please try again";
					this.loading = false;
					console.log(error);
				});
		},

		loginWithFacebook() {
			const provider = new firebase.FacebookAuthProvider();
			firebase
				.signInWithPopup(firebase.getAuth(), provider)
				.then((user) => {
					this.editedItem.token = user.user.accessToken;
					this.socialAuth(this.editedItem);
				})
				.catch((error) => {
					this.errorSnackbar = true;
					this.message =
						error.message ||
						"Somethting went wrong, please try again";
					this.loading = false;
					console.log(error);
				});
		},

		loginWithMicrosoft() {
			const provider = new firebase.OAuthProvider("microsoft.com");
			firebase
				.signInWithPopup(firebase.getAuth(), provider)
				.then((user) => {
					this.editedItem.token = user.user.accessToken;
					this.socialAuth(this.editedItem);
				})
				.catch((error) => {
					this.errorSnackbar = true;
					this.message =
						error.message ||
						"Somethting went wrong, please try again";
					this.loading = false;
					console.log(error);
				});
		},

		socialAuth(item) {
			return UserService.socialAuth(item).then(
				(response) => {
					if (response.data.statusCode === "AUTH003") {
						setTimeout(() => {
							this.successSnackbar = true;
							this.message = response.data.message;
							this.$router.push(
								this.$route.query.redirect || "/"
							);
						}, 1500);
						// this.loading = false;
					} else {
						console.log("log", response.data.statusCode);
						if (response.data.statusCode == "AUTH007") {
							this.successSnackbar = true;
							this.message = response.data.message;
							// this.$store.dispatch("auth/setSelectedEmail", this.user.email);
							this.$router.push("/initial-verification");
						}
						// this.loading = false;
						this.errorSnackbar = true;
						this.message = response.data.message
							? response.data.message
							: response.message;
						console.log(response);
					}
				},
				(error) => {
					this.errorSnackbar = true;
					this.message =
						error.message ||
						"Something went wrong please, try again";
					console.log(error);
				}
			);
		},
	},
};
</script>
<style scoped>
.v-btn::before {
	background-color: transparent;
}
</style>
