<template>
  <div>
    <div class="my-1 ml-n5">
      <span class="primary--text text-overline"
        >{{ Filename }}
        <v-icon color="primary m-3" x-small>mdi-chevron-right</v-icon></span
      >
    </div>

    <v-card class="elevation-1 pa-1">
      <PDFContainer :pdfFile="pdfFile" @loaded="handleLoaded"></PDFContainer>
    </v-card>
  </div>
</template>

<script>
import PDFContainer from "@/components/PDFContainer.vue";


export default {
  components: {
    PDFContainer,
  },

  data: () => ({
    Filename: "Sign Document",
    pdfFile: "/document.pdf",
  }),

  coomputed: {
    file() {
      return this.$store.state.selected_file;
    },
  },

  methods: {
    handleLoaded(instance) {
      console.log(instance, "Loaded");
    },

    openDocument(event) {
      if (this.pdfFile && this.pdfFile.startsWith("blob:")) {
        window.URL.revokeObjectURL(this.pdfFile);
      }
      this.pdfFile = window.URL.createObjectURL(event.target.file[0]);
    },

  },
};
</script>

<style>
</style>