<template>
  <div>
    <div class="mb-1 ml-n5"><span class="primary--text text-overline">{{Name}}<v-icon color="primary m-3" x-small>mdi-chevron-right</v-icon></span></div>
    <v-data-table
      :headers="headers"
      :items="items"
      :search="search"
      sort-by="id"
      class="elevation-1"
    >
      <template v-slot:top>
        <v-toolbar flat class="pt-2">
              <v-btn color="primary"  height="30" dark class="mb-4 ma-2"> Upload CSV </v-btn>
              <v-btn color="primary" height="30" dark class="mb-4 ma-2">
                Download CSV
              </v-btn>
          <!-- SEARCH FIELD -->
          <v-spacer></v-spacer>
          <v-col cols="12" sm="3" class="mt-5">
            <v-text-field
              label="Search"
              v-model="search"
              append-icon="mdi-magnify"
              dense
              small
              color="primary"
              outlined
            ></v-text-field>
          </v-col>
        </v-toolbar>
        <v-progress-linear
          indeterminate
          color="primary"
          v-if="loading"
        ></v-progress-linear>
      </template>
      <template v-slot:[`item.signature`]="{ item }">   
         <v-btn
      variant="outlined"
      v-if="item.signature"
      color="primary"
    >
      <span >Signed</span>
    </v-btn>
        <v-btn
      variant="outlined"
      v-else
      color="error"
    >
      <span class="caption">Pending</span>
    </v-btn>
    </template>
      <template v-slot:[`item.signDate`]="{ item }">{{item.signDate? formatDate(item.signDate) : N/A }}</template>
      <template v-slot:[`item.actions`]="{ item }">
        <v-btn
          color="primary"
          class="mx-1"
          fab
          x-small
          dark
          @click="editItem(item)"
        >
          <v-icon>mdi-eye</v-icon>
        </v-btn>
      </template>
    </v-data-table>
  </div>
</template>
<style>
.ck-editor__editable {
  min-height: 160px;
}
</style>

<script>
import FileService from "@/service/file.service";
import moment from 'moment';

export default {
  data: () => ({
    search: "",
    Name:'Shared Documents',
    items: [],
    technicalDocs: [],
    loading: true,
    dialog: false,
    dialogDelete: false,
    editedIndex: -1,
    valid: true,

    rules: {
      select: [(v) => !!v || "An item should be selected"],
      select2: [(v) => v.length > 0 || "At least one item should be selected"],
      required: [
        (v) => !!v || "Field is required",
        (v) => (v && v.length >= 1) || "Min 1 characters",
      ],
      numberRule: [
        (v) =>
          (!isNaN(parseFloat(v)) && v >= 0) ||
          "Number Required",
      ],
      fileRules: [
        value => !value || value.size < 10000000 || 'File size should be less than 10 MB!',
      ],
    },

    editedItem: {
      document: "",
      title: "",
      description: "",
      max_score: "",
    },

    headers: [
      {
        text: "#",
        align: "start",
        sortable: true,
        value: "id",
        width: "",
      },
      {
        text: "File",
        align: "start",
        sortable: false,
        value: "prospectEmail",
        width: "30%",
      },

      {
        text: "Status",
        align: "start",
        sortable: false,
        value: "signature",
        width: "30%",
      },
          {
        text: "Signed Date",
        align: "start",
        sortable: false,
        value: "signDate",
        width: "30%",
      },
      {
        text: "Actions",
        value: "actions",
        align: "center",
      },
    ],
  }),

  computed: {
    formTitle() {
      return this.editedIndex === -1 ? "New Configuration" : "Edit Configuration";
    },

  file() {
      return this.$store.state.selected_file;
    },
  },

  watch: {
    dialog(val) {
      val || this.close();
    },

    dialogDelete(val) {
      val || this.closeDelete();
    },
  },

  created() {
    this.getDocuSign();
  },


  methods: {
    filterTest(value, search) {
      return (
        value != null && search != null,
        typeof value === "string" &&
          value.toString().toLocalLowerCase(search) !== -1
      );
    },
    validate() {
      return this.$refs.form.validate();
    },

  // formarting date
    formatDate(date) {
      return moment(date).format("DD-MM-YYYY");
    },
    formatTime(date) {
      return moment(date).format("h:mm a");
    },

    // get Docusigns
    getDocuSign() {
      return FileService.getDocuSign(101).then(
        (Response) => {
          if (Response.status == 200) {
            this.items = Response.data.data;
            console.log('items we want', this.items)
            this.loading = false;
          } else {
            this.items = [];
            this.loading = false;
            console.log(Response.data.console.error);
          }
        },
        (error) => {
          this.items = [];
          console.log(error);
        }
      );
    },

    // Edit Item
    editItem(item) {
      this.editedIndex = this.items.indexOf(item);
      this.editedItem = Object.assign({}, item);
      this.$router.push("/sign");
      this.$store.dispatch("file/setSelectedFile", item);
    },

    // Close Dialog
    close() {
      this.dialog = false;
      this.$nextTick(() => {
        this.editedItem = Object.assign({}, this.defaultItem);
        this.editedIndex = -1;
      });
    },

    closeDelete() {
      this.dialogDelete = false;
      this.$nextTick(() => {
        this.editedItem = Object.assign({}, this.defaultItem);
        this.editedIndex = -1;
      });
    },
  },
};
</script>
