<template>
  <div>
    <div class="mb-1 ml-n5">
      <span class="primary--text text-overline"
        >{{ Filename
        }}<v-icon color="primary m-3" x-small>mdi-chevron-right</v-icon></span
      >
    </div>
    <v-data-table
      :headers="tableHerders"
      :items="items"
      :search="search"
      sort-by="id"
      class="elevation-1"
    >
      <template v-slot:top>
        <v-toolbar flat class="pt-2">
          <!-- CREATE & UPDATE FILE DIALOG -->
          <v-dialog v-model="dialog" max-width="450px">
            <!-- ADD, UPLOAD & DOWNLOAD BUTTONS -->
            <template v-slot:activator="{ on, attrs }">
              <v-btn
                color="primary"
                dark
                class="mb-4 ma-2"
                height="30"
                v-bind="attrs"
                v-on="on"
              >
                Add File
              </v-btn>
              <v-btn color="primary" dark height="30" class="mb-4 ma-2">
                Download CSV
              </v-btn>
            </template>
            <v-card rounded="lg" max-width="450">
              <v-card-title class="error--text text--darken-1">
                <span class="text-h5 primary--text">{{ formTitle }}</span>
              </v-card-title>
              <v-divider></v-divider>
              <v-card-text>
                <v-container>
                  <v-form ref="form" v-model="valid">
                    <v-row>
                      <v-col cols="12" sm="12" md="12" class="mb-n9">
                        <v-text-field
                          v-model="editedItem.orgId"
                          label="Organization Id"
                          :rules="rules.numberRule"
                          color="grey"
                          dense
                          outlined
                          class="mt-4"
                        >
                          <template v-slot:label>
                            <span class="input__label"
                              >Organization Id
                              <v-icon small color="error" class="mt-n2"
                                >mdi-star-outline</v-icon
                              ></span
                            >
                          </template>
                        </v-text-field>
                      </v-col>
                      <v-col cols="12" sm="12" md="12" class="mb-n9">
                        <v-text-field
                          v-model="editedItem.email"
                          label="Email"
                          :rules="rules.required"
                          color="grey"
                          dense
                          outlined
                          class="mt-4"
                        >
                          <template v-slot:label>
                            <span class="input__label"
                              >Email
                              <v-icon small color="error" class="mt-n2"
                                >mdi-star-outline</v-icon
                              ></span
                            >
                          </template>
                        </v-text-field>
                      </v-col>

                      <v-col cols="12" sm="12" md="12" class="mb-n9">
                        <v-text-field
                          v-model="editedItem.modifiedBy"
                          label="modified By"
                          :rules="rules.required"
                          color="grey"
                          dense
                          outlined
                          class="mt-4"
                        >
                          <template v-slot:label>
                            <span class="input__label"
                              >Modified By
                              <v-icon small color="error" class="mt-n2"
                                >mdi-star-outline</v-icon
                              ></span
                            >
                          </template>
                        </v-text-field>
                      </v-col>

                      <v-col cols="12" sm="12" md="12" class="mb-n9">
                        <v-text-field
                          v-model="editedItem.fileName"
                          label="File Name"
                          :rules="rules.required"
                          color="grey"
                          dense
                          outlined
                          class="mt-4"
                        >
                          <template v-slot:label>
                            <span class="input__label"
                              >File Name
                              <v-icon small color="error" class="mt-n2"
                                >mdi-star-outline</v-icon
                              ></span
                            >
                          </template>
                        </v-text-field>
                      </v-col>
                      <v-col cols="12" sm="12" md="12" class="mb-n9">
                        <v-text-field
                          v-model="editedItem.hash"
                          label="File Code"
                          :rules="rules.required"
                          color="grey"
                          dense
                          outlined
                          class="mt-4"
                        >
                          <template v-slot:label>
                            <span class="input__label"
                              >File Code
                              <v-icon small color="error" class="mt-n2"
                                >mdi-star-outline</v-icon
                              ></span
                            >
                          </template>
                        </v-text-field>
                      </v-col>

                      <!-- File Upload -->
                      <v-col cols="=12" sm="12" md="12" class="mt-4">
                        <v-file-input
                          color="grey"
                          show-size
                          prepend-icon=""
                          outlined
                          dense
                          :rules="rules.files"
                          v-model="editedItem.file"
                          multiple
                        >
                          <template v-slot:label>
                            <span class="input__label">
                              <v-icon small color="primary"
                                >mdi-plus-thick</v-icon
                              ></span
                            >Click to Upload File
                          </template>
                        </v-file-input>
                      </v-col>
                    </v-row>
                  </v-form>
                </v-container>
              </v-card-text>

              <v-card-actions class="mr-4 mt-n6">
                <v-spacer></v-spacer>
                <v-btn
                  color="error"
                  class="text-capitalize mx-1"
                  height="30"
                  dark
                  @click="close"
                >
                  Cancel <v-icon small>mdi-cancel</v-icon>
                </v-btn>
                <v-btn
                  color="primary"
                  dark
                  class="text-capitalize mx-1"
                  height="30"
                  :loading="loading"
                  @click="handleFileUpload"
                >
                  Submit
                  <v-icon>mdi-content-save-outline</v-icon>
                </v-btn>
              </v-card-actions>
            </v-card>
          </v-dialog>

          <!-- SHARE FILE DIALOG -->
          <v-dialog v-model="shareDialog" max-width="450px">
            <v-card rounded="lg" max-width="450">
              <v-card-title class="error--text text--darken-1">
                <span class="text-h5 primary--text">Share File</span>
              </v-card-title>
              <v-divider></v-divider>
              <v-card-text>
                <v-container>
                  <v-form ref="form" v-model="valid">
                    <v-row>
                      <v-col cols="12" sm="12" md="12" class="mt-5 mb-n7">
                        <v-combobox
                          v-model="docEditedItem.emails"
                          :items="users"
                          label="Enter Email(s)"
                          chips
                          :rules="rules.select"
                          color="primary"
                          item-color="primary"
                          item-text="emailId"
                          item-value="emailId"
                          multiple
                          clearable
                          deletable-chips
                          outlined
                        >
                          <template v-slot:label>
                            <span class="input__label"
                              >Email(s)
                              <v-icon small color="error" class="mt-n2"
                                >mdi-star-outline</v-icon
                              ></span
                            >
                          </template>
                          <template v-slot:prepend-item>
                            <v-list-item ripple @click="toggleEmails">
                              <v-list-item-action>
                                <v-icon
                                  :color="
                                    docEditedItem.emails.length > 0
                                      ? 'primary'
                                      : ''
                                  "
                                >
                                  {{ iconUserEmails }}
                                </v-icon>
                              </v-list-item-action>
                              <v-list-item-content>
                                <v-list-item-title>
                                  Select All
                                </v-list-item-title>
                              </v-list-item-content>
                            </v-list-item>
                            <v-divider class="mt-2"></v-divider>
                          </template>
                          <template v-slot:append-item>
                            <v-divider class="mb-2"></v-divider>
                            <v-list-item color="primary" disabled>
                              <v-list-item-avatar color="grey lighten-3">
                                <v-icon> mdi-file-outline </v-icon>
                              </v-list-item-avatar>
                              <v-list-item-content v-if="likesAllUserEmails">
                                <v-list-item-title>
                                  All Emails Selected for This Document!
                                </v-list-item-title>
                              </v-list-item-content>

                              <v-list-item-content
                                v-else-if="likesSomeUserEmails"
                              >
                                <v-list-item-title>
                                  Emails Count
                                </v-list-item-title>
                                <v-list-item-subtitle>
                                  {{
                                    docEditedItem.emails.length
                                  }}
                                </v-list-item-subtitle>
                              </v-list-item-content>

                              <v-list-item-content v-else>
                                <v-list-item-title>
                                  Which Emails would like to share the document?
                                </v-list-item-title>
                                <v-list-item-subtitle>
                                  Go ahead, make a selection above!
                                </v-list-item-subtitle>
                              </v-list-item-content>
                            </v-list-item>
                          </template>
                          <!-- end of select emails -->
                        </v-combobox>
                      </v-col>
                    </v-row>
                  </v-form>
                </v-container>
              </v-card-text>

              <v-card-actions class="mr-4">
                <v-spacer></v-spacer>
                <v-btn
                  color="error"
                  class="text-capitalize mx-1"
                  dark
                  @click="close"
                >
                  Cancel <v-icon small>mdi-cancel</v-icon>
                </v-btn>
                <v-btn
                  color="primary"
                  dark
                  class="text-capitalize mx-1"
                  @click="saveEmails"
                  :loading="loading"
                >
                  Share
                  <v-icon>mdi-content-save-outline</v-icon>
                </v-btn>
              </v-card-actions>
            </v-card>
          </v-dialog>

          <!-- SEARCH FIELD -->
          <v-spacer></v-spacer>
          <v-col cols="12" sm="3" class="mt-5">
            <v-text-field
              label="Search"
              v-model="search"
              append-icon="mdi-magnify"
              dense
              small
              color="primary"
              outlined
            ></v-text-field>
          </v-col>
          <v-col cols="12" sm="3" class="mt-5">
            <v-autocomplete
              :items="headers"
              label="Select Column(s)"
              multiple
              closable
              value="text"
              :rules="rules.select"
              color="primary"
              v-model="selectedHeaders"
              dense
              outlined
            >
              <template v-slot:selection="{ item, index }">
                <v-chip
                  small-chips
                  color="secondary"
                  class="ma-1"
                  v-if="index < 1"
                >
                  <span class="caption primary--text">{{ item.text }}</span>
                </v-chip>
                <span
                  v-if="index === 1"
                  class="primary--text text-caption align-self-center"
                >
                  (+{{ selectedHeaders.length - 1 }} others)
                </span>
              </template>
            </v-autocomplete>
          </v-col>
        </v-toolbar>
        <v-progress-linear
          indeterminate
          color="primary"
          v-if="loading"
        ></v-progress-linear>
      </template>
      <template v-slot:[`item.fileName`]="{ item }">
        <a :href="item.path" target="_blank">{{ item.fileName }}</a>
      </template>

      <template v-slot:[`item.actions`]="{ item }">
        <v-btn
          color="primary"
          class="mx-1"
          fab
          x-small
          dark
          @click="editItem(item)"
        >
          <v-icon>mdi-pencil</v-icon>
        </v-btn>

        <v-btn
          color="error"
          class="mx-1"
          fab
          x-small
          dark
          @click="deleteItem(item)"
        >
          <v-icon>mdi-delete</v-icon>
        </v-btn>

        <v-tooltip bottom>
          <template v-slot:activator="{ on, attrs }">
            <v-btn
              color="secondary"
              class="mx-1"
              fab
              x-small
              v-bind="attrs"
              v-on="on"
              dark
              @click="shareFile(item)"
            >
              <v-icon color="primary">mdi-share</v-icon>
            </v-btn>
          </template>
          <span class="caption">Share File</span>
        </v-tooltip>
      </template>
    </v-data-table>
  </div>
</template>
<style>
.ck-editor__editable {
  min-height: 160px;
}
</style>

<script>
import FileService from "@/service/file.service";
import Users from "@/service/user.service";
import Swal from "sweetalert2";

export default {
  props: { orgId: {} },
  data: () => ({
    items: [],
    users: [],
    // orgId: 4,
    Filename: "Manage Files",
    search: "",
    loading: false,
    prependIcon: false,
    dialog: false,
    shareDialog: false,
    emails: [
      { email: "mikenzioki65@gmail.com", name: "Mike Nzioki" },
      { email: "paulodhiambo962@gmail.com", name: "Paul Odhiambo" },
      { email: "mikeray563@gmail.com", name: "Ray Ray   " },
    ],
    dialogDelete: false,
    editedIndex: -1,
    valid: true,
    selectedHeaders: ["id", "orgId", "fileName", "hash", "type", "actions"],

    // Headers
    headers: [
      {
        text: "#",
        align: "start",
        sortable: true,
        value: "id",
      },
      {
        text: "Organization Id",
        align: "start",
        sortable: false,
        value: "orgId",
      },
      {
        text: "File",
        align: "start",
        sortable: false,
        value: "fileName",
      },
      {
        text: "Type",
        align: "start",
        sortable: false,
        value: "type",
      },
      {
        text: "File Hash",
        align: "start",
        sortable: false,
        value: "hash",
      },
      {
        text: "Actions",
        value: "actions",
        align: "center",
      },
    ],

    // Rules
    rules: {
      select: [(v) => !!v || "An item should be selected"],
      select2: [(v) => v.length > 0 || "At least one item should be selected"],
      required: [
        (v) => !!v || "Field is required",
        (v) => (v && v.length >= 1) || "Min 1 characters",
      ],
      numberRule: [
        (v) => (!isNaN(parseFloat(v)) && v >= 0) || "Item should be a number",
      ],
      files: [
        (files) =>
          !files ||
          !files.some((file) => file.size > 10000000) ||
          "File size should be less than 10 MB!",
      ],

      fileRules: [
        (value) =>
          !value ||
          value.size < 10000000 ||
          "file size should be less than 10 MB!",
      ],
    },

    // EditedItem
    editedItem: {
      subscriberId: "",
      hash: "",
      fileName: "",
      file: [],
      id: "",
    },

    // defaultItem
    defaultItem: {
      subscriberId: "",
      hash: "",
      fileName: "",
      file: [],
      id: "",
    },

    docEditedItem: {
      emails: "",
      documentId: "",
    },

    defaulDocEditedItem: {
      emails: "",
      documentId: "",
    },
  }),

  watch: {
    dialog(val) {
      val || this.close();
    },

    dialogDelete(val) {
      val || this.closeDelete();
    },
  },

  computed: {
    formTitle() {
      return this.editedIndex === -1 ? "New File" : "Edit File";
    },
    tableHerders() {
      return this.headers.filter((header) =>
        this.selectedHeaders.includes(header.value)
      );
    },
    disableSort() {
      return this.headers
        .filter((header) => !this.selectedHeaders.includes(header.value))
        .map((header) => header.value);
    },

    // user emails
    likesAllUserEmails() {
      return this.docEditedItem.emails.length === this.users.length;
    },
    likesSomeUserEmails() {
      return this.docEditedItem.emails.length > 0 && !this.likesAllUserEmails;
    },
    iconUserEmails() {
      if (this.likesAllUserEmails) return "mdi-close-box";
      if (this.likesSomeUserEmails) return "mdi-minus-box";
      return "mdi-checkbox-blank-outline";
    },
  },

  created() {
    this.getAllFiles();
    this.getUsers();
  },

  methods: {
    getAllFiles() {
      return FileService.getUserFiles(this.orgId).then(
        (Response) => {
          if (Response.status == 200) {
            this.items = Response.data.data;
            this.loading = false;
          } else {
            this.items = [];
            this.loading = false;
            console.log(Response.data.console.error);
          }
        },
        (error) => {
          this.items = [];
          console.log(error);
        }
      );
    },

    // get users
    getUsers() {
      return Users.index().then(
        (response) => {
          if (response.status == 200) {
            this.users = response.data.data;
            this.loading = false;
          } else {
            this.users = [];
            this.loading = false;
            console.log(response.data.console.error);
          }
        },
        (error) => {
          this.users = [];
          console.log(error);
        }
      );
    },

    // Open New
    openNew() {
      this.editedItem.subscriberId = "";
      this.editedItem.hash = "";
      this.editedItem.fileName = "";
      this.editedItem.file = "";
      this.dialog = true;
    },

    // Edit Item
    editItem(item) {
      this.editedIndex = this.items.indexOf(item);
      this.editedItem = Object.assign({}, item);
      this.editedItem.id = item.id;
      console.log(this.editedItem, "the edit you");
      this.dialog = true;
    },

    // shareFile
    shareFile(item) {
      this.editedIndex = this.items.indexOf(item);
      this.editedItem = Object.assign({}, item);
      this.docEditedItem.documentId = this.editedItem.documentId;
      this.shareDialog = true;
    },

    // Delete Config
    deleteItem(item) {
      Swal.fire({
        title: "Are you sure you want to delete this item?",
        text: "You cannot undo this action",
        icon: "warning",
        showCancelButton: true,
      }).then((result) => {
        if (result.isConfirmed) {
          this.editedIndex = this.items.indexOf(item);
          this.editedItem = Object.assign({}, item);
          this.items.splice(this.editedIndex, 1);

          FileService.deleteFile(this.editedItem).then(
            (response) => {
              if (response.status == 201) {
                this.close();
                this.$store.dispatch("alert/success", response.data.message);
              } else {
                this.close();
                this.$store.dispatch("alert/error", response.data.message);
              }
              this.getAllFiles();
            },
            (error) => {
              if (error.response.status == 422) {
                this.close();
                this.$store.dispatch(
                  "alert/error",
                  error.response.data.message
                );
              }
              console.log(error);
              this.close();
              this.$store.dispatch("alert/error", error.response.data.message);
            }
          );
        }
      });
    },

    // close dialog
    close() {
      this.dialog = false;
      this.shareDialog = false;
      this.$nextTick(() => {
        this.editedItem = Object.assign({}, this.defaultItem);
        this.docEditedItem = Object.assign({}, this.defaulDocEditedItem);
        this.editedIndex = -1;
      });
    },

    // Save File
    async handleFileUpload() {
      console.log("uploading...");
      let formData = {};
      formData["orgId"] = this.editedItem.orgId;
      formData["table_name"] = this.editedItem.fileName;
      formData["column_name"] = this.editedItem.fileName;
      formData["primary_id"] = this.editedItem.hash;
      formData["email"] = this.editedItem.email;
      formData["modifiedBy"] = this.editedItem.modifiedBy;
      formData["file"] = this.editedItem.file[0];

      if (this.editedIndex > -1) {
        // EDIT FILE
        formData["id"] = this.editedItem.id;
        console.log(formData, "edit");
        FileService.updateFile(formData).then(
          (response) => {
            if (response.status == 200) {
              this.close();
              this.$store.dispatch(
                "alert/success",
                "Required Document Uploaded!"
              );
              this.file = null;
              this.getAllFiles();
              this.loading = false;
            } else {
              this.close();
              this.$store.dispatch("alert/error", response.message);
              this.loading = false;
            }
          },
          (error) => {
            this.loading = false;
            if (error.response.status == 403) {
              console.log(error.response.data.errors);
              this.message = error.response.data.data.message;
            } else {
              this.message =
                (error.response && error.response.data) ||
                error.message ||
                error.toString() ||
                "Internal Server Error";
            }
            this.close();
            this.$store.dispatch("alert/error", this.message);
            this.loading = false;
          }
        );
      } else {
        // CREATE FILE
        FileService.uploadFile(formData).then(
          (response) => {
            if (response.status == 200) {
              this.close();
              this.$store.dispatch(
                "alert/success",
                "Required Document Uploaded!"
              );
              this.file = null;
              this.getAllFiles();
              this.loading = false;
            } else {
              this.close();
              this.$store.dispatch("alert/error", response.message);
              this.loading = false;
            }
          },
          (error) => {
            this.loading = false;
            if (error.response.status == 403) {
              console.log(error.response.data.errors);
              this.message = error.response.data.message;
            } else {
              this.message =
                (error.response && error.response.data) ||
                error.message ||
                error.toString() ||
                "Internal Server Error";
            }
            this.close();
            this.$store.dispatch("alert/error", this.message);
            this.loading = false;
          }
        );
      }
    },

    // Toggle User Emails
    toggleEmails() {
      this.$nextTick(() => {
        if (this.likesAllUserEmails) {
          this.docEditedItem.emails = [];
        } else {
          this.docEditedItem.emails = this.users.map((user) => {
            return user;
          });
        }
      });
    },

    // save Emails and share/send mail
    saveEmails() {
      this.docEditedItem.documentId = this.editedItem.id;
      this.docEditedItem.orgId = parseInt(this.editedItem.orgId);
      this.docEditedItem.path = this.editedItem.path;
      this.docEditedItem.fileName = this.editedItem.fileName;

      console.log("inch", this.docEditedItem);
      FileService.addSignatureMails(this.docEditedItem).then(
        (response) => {
          if (response.status == 200) {
            console.log("the ress", response);
            this.close();
            this.$store.dispatch(
              "alert/success",
              "Draft Created Successfully!"
            );
            this.$store.dispatch("file/setSelectedFile", response.data);
            this.$router.push("/share-doc");
            this.loading = false;
          } else {
            this.close();
            this.$store.dispatch("alert/error", response.data.error);
            this.loading = false;
          }
        },
        (error) => {
          console.log(error.response.data.error, "the rrrorr");
          this.loading = false;
          if (error.response.status == 403) {
            console.log(error.response.data.error);
            this.message = error.response.data.error;
          } else {
            this.message =
              (error.response && error.response.data) ||
              error.message ||
              error.toString() ||
              "Internal Server Error";
          }
          this.close();
          this.$store.dispatch("alert/error", this.message.error);
          this.loading = false;
        }
      );
    },
  },
};
</script>
