<template>
  <div>
    <v-card class="elevation-1 pa-1">
      <iframe
        id="prepare_page"
        :src="file.sendUrl"
        height="950"
        width="100%"
        class="frame"
      >
      </iframe>
    </v-card>
  </div>
</template>

<script>
export default {
  data: () => ({}),
  computed: {
    file() {
      return this.$store.state.file.selected_file;
    },
  },

  created() {
    this.sharedCallback();
  },

  methods: {
    sharedCallback() {
      window.addEventListener("message", function (params) {
        if (params.origin !== "https://app.boldsign.com") {
          return;
        }
        switch (params.data) {
          case "onCreateSuccess":
            // handle create success
            window.location.replace('/web');
            break;
          default:
            window.location.replace(process.env.VUE_APP_BASE_URL);
            break;
        }
      });
    },
  },
};
</script>
