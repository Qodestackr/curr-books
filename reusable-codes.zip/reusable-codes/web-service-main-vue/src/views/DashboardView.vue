<template>
  <v-card
    class="mx-auto"
    max-width="1100"
    height="100%"
  >
    <v-card-text>
      <div>Dashboard</div>
      <p class="text-h4 text--primary">
        Da•sh•bo•ard
      </p>
      <p>adjective</p>
      <div class="text--primary">
        well meaning and kindly.<br>
        "a benevolent smile"
      </div>
    </v-card-text>
    <v-card-actions>
      <v-btn
        text
        color="deep-purple accent-4"
      >
        Learn More
      </v-btn>
    </v-card-actions>
  </v-card>
</template>

<script>
export default {

}
</script>

<style>

</style>