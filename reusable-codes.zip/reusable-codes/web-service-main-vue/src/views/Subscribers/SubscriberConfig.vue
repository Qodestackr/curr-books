<template>
	<div>
		<div class="mb-1 ml-n5">
			<span class="primary--text text-overline"
				>{{ Name
				}}<v-icon color="primary m-3" x-small
					>mdi-chevron-right</v-icon
				></span
			>
		</div>
		<v-data-table
			:headers="headers"
			:items="items"
			:search="search"
			sort-by="id"
			class="elevation-1"
		>
			<template v-slot:top>
				<v-toolbar flat class="pt-2">
					<v-dialog v-model="dialog" max-width="450px">
						<!-- ADD, UPLOAD & DOWNLOAD BUTTONS -->
						<template v-slot:activator="{ on, attrs }">
							<v-btn
								color="primary"
								dark
								class="mb-4 ma-2"
								height="30"
								v-bind="attrs"
								v-on="on"
							>
								Add Configuration
							</v-btn>

							<v-btn
								color="primary"
								height="30"
								dark
								class="mb-4 ma-2"
							>
								Upload CSV
							</v-btn>
							<v-btn
								color="primary"
								height="30"
								dark
								class="mb-4 ma-2"
							>
								Download CSV
							</v-btn>
						</template>
						<v-card rounded="lg" max-width="450">
							<v-card-title class="error--text text--darken-1">
								<span class="text-h5 primary--text">{{
									formTitle
								}}</span>
							</v-card-title>
							<v-divider></v-divider>

							<v-card-text>
								<v-container>
									<v-form ref="form" v-model="valid">
										<v-row>
											<!-- SubscriberId -->
											<v-col
												cols="12"
												sm="12"
												md="12"
												class="mb-n8"
											>
												<v-text-field
													v-model="editedItem.orgId"
													label="OrganizationId"
													:rules="rules.required"
													color="grey"
													dense
													outlined
													class="mt-4"
												>
													<template v-slot:label>
														<span
															class="input__label"
															>Organization Id
															<v-icon
																small
																color="error"
																class="mt-n2"
																>mdi-star-outline</v-icon
															></span
														>
													</template>
												</v-text-field>
											</v-col>

											<!-- Created By -->
											<v-col
												cols="12"
												sm="12"
												md="12"
												class="mb-n9"
											>
												<v-text-field
													v-model="
														editedItem.createdBy
													"
													label="Created By"
													:rules="rules.required"
													color="grey"
													dense
													outlined
													class="mt-4"
												>
													<template v-slot:label>
														<span
															class="input__label"
															>Created By
															<v-icon
																small
																color="error"
																class="mt-n2"
																>mdi-star-outline</v-icon
															></span
														>
													</template>
												</v-text-field>
											</v-col>

											<!-- Modified By -->
											<v-col
												cols="12"
												sm="12"
												md="12"
												class="mb-n9"
											>
												<v-text-field
													v-model="
														editedItem.modifiedBy
													"
													label="modifiedBy"
													:rules="rules.required"
													color="grey"
													dense
													outlined
													class="mt-4"
												>
													<template v-slot:label>
														<span
															class="input__label"
															>Modified By
															<v-icon
																small
																color="error"
																class="mt-n2"
																>mdi-star-outline</v-icon
															></span
														>
													</template>
												</v-text-field>
											</v-col>

											<v-row
												:v-if="editedIndex <= 0"
												class="mt-1"
											>
												<!-- Upload Quota -->
												<v-col
													cols="12"
													sm="12"
													md="12"
													class="mb-n9"
												>
													<v-text-field
														v-model="
															editedItem.maxFileUploadSize
														"
														label="Max-Upload Size (MB)"
														:rules="
															rules.numberRule
														"
														color="grey"
														dense
														outlined
														class="mt-4 mx-3"
													>
														<template v-slot:label>
															<span
																class="input__label"
																>Max-Upload Size
																(MB)
																<v-icon
																	small
																	color="error"
																	class="mt-n2"
																	>mdi-star-outline</v-icon
																></span
															>
														</template>
													</v-text-field>
												</v-col>

												<!-- Storage Quota -->
												<v-col
													cols="12"
													sm="12"
													md="12"
													class="mb-n9"
												>
													<v-text-field
														v-model="
															editedItem.maxAllocatedStorageSize
														"
														label="Storage Quota"
														:rules="
															rules.numberRule
														"
														color="grey"
														dense
														outlined
														class="mt-4 mx-3"
													>
														<template v-slot:label>
															<span
																class="input__label"
																>Storage Quota
																(GB)
																<v-icon
																	small
																	color="error"
																	class="mt-n2"
																	>mdi-star-outline</v-icon
																></span
															>
														</template>
													</v-text-field>
												</v-col>
											</v-row>
										</v-row>
									</v-form>
								</v-container>
							</v-card-text>

							<v-card-actions class="mr-4">
								<v-spacer></v-spacer>
								<v-btn
									color="error"
									class="text-capitalize mx-1"
									height="30"
									dark
									@click="close"
								>
									Cancel <v-icon small>mdi-cancel</v-icon>
								</v-btn>
								<v-btn
									color="primary"
									dark
									class="text-capitalize mx-1"
									height="30"
									:loading="false"
									@click="save"
								>
									Save
									<v-icon>mdi-content-save-outline</v-icon>
								</v-btn>
							</v-card-actions>
						</v-card>
					</v-dialog>

					<!-- SEARCH FIELD -->
					<v-spacer></v-spacer>
					<v-col cols="12" sm="3" class="mt-5">
						<v-text-field
							label="Search"
							v-model="search"
							append-icon="mdi-magnify"
							dense
							small
							color="primary"
							outlined
						></v-text-field>
					</v-col>
				</v-toolbar>
				<v-progress-linear
					indeterminate
					color="primary"
					v-if="loading"
				></v-progress-linear>
			</template>
			<template v-slot:[`item.value`]="{ item }">{{
				item.settingName === "STORAGE_QUOTA_GB"
					? item.value + "GB"
					: item.value + "MB"
			}}</template>
			<template v-slot:[`item.createdOn`]="{ item }">{{
				formatDate(item.createdOn)
			}}</template>
			<template v-slot:[`item.modifiedOn`]="{ item }">{{
				formatDate(item.modifiedOn)
			}}</template>
			<template v-slot:[`item.actions`]="{ item }">
				<v-btn
					color="primary"
					class="mx-1"
					fab
					x-small
					dark
					@click="editItem(item)"
				>
					<v-icon>mdi-pencil</v-icon>
				</v-btn>

				<v-btn
					color="error"
					class="mx-1"
					fab
					x-small
					dark
					@click="deleteItem(item)"
				>
					<v-icon>mdi-delete</v-icon>
				</v-btn>
			</template>
		</v-data-table>
	</div>
</template>
<style>
.ck-editor__editable {
	min-height: 160px;
}
</style>

<script>
import ConfigurationService from "@/service/configuration.service";
import moment from "moment";
import Swal from "sweetalert2";

export default {
	props:{orgId: {}},
	data: () => ({
		search: "",
		Name: "Configurations",
		items: [],
		technicalDocs: [],
		loading: true,
		dialog: false,
		dialogDelete: false,
		editedIndex: -1,
		valid: true,

		rules: {
			select: [(v) => !!v || "An item should be selected"],
			select2: [
				(v) => v.length > 0 || "At least one item should be selected",
			],
			required: [
				(v) => !!v || "Field is required",
				(v) => (v && v.length >= 1) || "Min 1 characters",
			],
			numberRule: [
				(v) => (!isNaN(parseFloat(v)) && v >= 0) || "Number Required",
			],
			fileRules: [
				(value) =>
					!value ||
					value.size < 10000000 ||
					"File size should be less than 10 MB!",
			],
		},

		editedItem: {
			maxAllocatedStorageSize: "",
			orgId: "",
			modifiedBy: "",
			maxFileUploadSize: "",
		},

		defaultItem: {
			maxAllocatedStorageSize: "",
			orgId: "",
			modifiedBy: "",
			maxFileUploadSize: "",
		},

		headers: [
			{
				text: "Organization (Id)",
				align: "start",
				sortable: true,
				value: "orgId",
			},
			{
				text: "Settings Name",
				align: "start",
				sortable: false,
				value: "settingName",
			},
			{
				text: "Value",
				align: "start",
				sortable: false,
				value: "value",
			},
			{
				text: "Created By",
				align: "start",
				sortable: false,
				value: "createdBy",
			},
			{
				text: "Created On",
				align: "start",
				sortable: false,
				value: "createdOn",
			},
			{
				text: "modified By",
				align: "start",
				sortable: false,
				value: "modifiedBy",
			},
			{
				text: "modified On",
				align: "start",
				sortable: false,
				value: "modifiedOn",
			},
			{
				text: "Actions",
				value: "actions",
				align: "center",
			},
		],
	}),

	computed: {
		formTitle() {
			return this.editedIndex === -1
				? "New Configuration"
				: "Edit Configuration";
		},
	},

	watch: {
		dialog(val) {
			val || this.close();
		},

		dialogDelete(val) {
			val || this.closeDelete();
		},
	},

	created() {
		this.getConfigurations();
	},

	methods: {
		filterTest(value, search) {
			return (
				value != null && search != null,
				typeof value === "string" &&
					value.toString().toLocalLowerCase(search) !== -1
			);
		},
		validate() {
			return this.$refs.form.validate();
		},

		getConfigurations() {
			return ConfigurationService.getConfigurations(this.orgId).then(
				(response) => {
					if (response.status == 200) {
						this.items = response.data.data;
						this.loading = false;
					} else {
						this.items = [];
						this.loading = false;
						console.log(response.data.console.error);
					}
				},
				(error) => {
					this.items = [];
					console.log(error);
				}
			);
		},

		// formart Date

		formatDate(date) {
			return moment(date).format("DD-MM-YYYY");
		},

		// Edit Item
		editItem(item) {
			this.editedIndex = this.items.indexOf(item);
			console.log(this.editedIndex, "the indexx");
			this.editedItem = Object.assign({}, item);
			this.dialog = true;
		},

		// Delete
		deleteItem(item) {
			Swal.fire({
				title: "Are you sure you want to delete this item?",
				text: "You cannot undo this action",
				color: "primary",
				icon: "warning",
				showCancelButton: true,
			}).then((result) => {
				if (result.isConfirmed) {
					this.editedIndex = this.items.indexOf(item);
					this.editedItem = Object.assign({}, item);
					this.items.splice(this.editedIndex, 1);

					ConfigurationService.deleteConfiguration(
						this.editedItem
					).then(
						(response) => {
							if (response.status == 200) {
								this.$store.dispatch(
									"alert/success",
									response.data.message
								);
								this.close();
							} else {
								this.$store.dispatch(
									"alert/error",
									response.data.message
								);
							}
						},
						(error) => {
							if (error.response.status == 422) {
								this.$store.dispatch(
									"alert/error",
									error.response.data.message
								);
							}
							console.log(error);
							this.$store.dispatch(
								"alert/error",
								error.response.data.message
							);
						}
					);
				}
			});
		},

		// Close Dialog
		close() {
			this.dialog = false;
			this.$nextTick(() => {
				this.editedItem = Object.assign({}, this.defaultItem);
				this.editedIndex = -1;
			});
		},

		// Save
		save() {
			this.valid = this.validate();
			if (this.valid) {
				this.editedItem.orgId = parseInt(this.editedItem.orgId);
				this.editedItem.maxAllocatedStorageSize = parseFloat(this.editedItem.maxAllocatedStorageSize);
				this.editedItem.maxFileUploadSize = parseFloat(this.editedItem.maxFileUploadSize);
				console.log('thisthis', this.editedItem);

				this.loading = true;
				// edit
				if (this.editedIndex > -1) {
					Object.assign(
						this.items[this.editedIndex],
						this.editedItem
					);
					console.log(this.editedItem);

					ConfigurationService.updateConfiguration(
						this.editedItem
					).then((response) => {
						if (response.status === 200) {
							this.$store.dispatch(
								"alert/success",
								response.data.message
							);
							this.getConfigurations();
							this.loading = false;
							this.close();
						} else {
							this.$store.dispatch(
								"alert/error",
								"Invalid data, please check the form try again!"
							);
							this.loading = false;
						}
						(error) => {
							if (error.response.status === 422) {
								this.$store.dispatch(
									"alert/error",
									error.response.data.message
								);
							}
							this.$store.dispatch(
								"alert/error",
								error.response.data.message
							);
							this.loading = false;
						};
					});
				} else {
					// Create
					ConfigurationService.storeConfiguration(
						this.editedItem
					).then(
						(response) => {
							if (response.status === 201) {
								this.items.push(this.editedItem);
								this.$store.dispatch(
									"alert/success",
									"Added Successfully"
								);
								this.getConfigurations();
								this.loading = false;
								this.close();
							} else {
								this.$store.dispatch(
									"alert/error",
									"Something Went Wrong!"
								);

								this.loading = false;
							}
						},
						(error) => {
							this.loading = false;
							if (error.response.status === 422) {
								this.$store.dispatch("alert/error", error);
							}
							this.$store.dispatch(
								"alert/error",
								error.response.data.message
							);
						}
					);
				}
			}
		},

		closeDelete() {
			this.dialogDelete = false;
			this.$nextTick(() => {
				this.editedItem = Object.assign({}, this.defaultItem);
				this.editedIndex = -1;
			});
		},
	},
};
</script>
