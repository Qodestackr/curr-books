<template>
  <v-app id="inspire">
    <div>
      <!-- NavDrawer -->
      <v-navigation-drawer
        v-model="drawer"
        :mini-variant.sync="mini"
        clipped
        :permanent="!$vuetify.breakpoint.xsOnly"
        fixed
        color="secondary"
        app
        class="sticky"
      >
        <v-list
          rounded
          :class="mini ? 'my-n3 ml-n1' : 'my-n1 ml-n1'"
          v-for="item in adminMenu"
          :key="item.title"
        >
          <v-list-group
            :append-icon="null"
            color="secondary"
            v-if="item.child"
            :to="item.route"
            :class="mini ? 'mt-n2' : 'mt-n6 py-n10'"
          >
            <template v-slot:activator>
              <v-list-item-icon>
                <v-btn
                  :color="item.color"
                  fab
                  dark
                  small
                  class="my-n2 ml-n2"
                  v-if="mini"
                  ><v-icon>{{ item.icon }}</v-icon></v-btn
                >
                <v-btn :color="item.color" fab small dark class="" v-else
                  ><v-icon>{{ item.icon }}</v-icon></v-btn
                >
              </v-list-item-icon>
              <div>
                <v-list-item-content class="primary--text py-n10">
                  <v-list-item-title
                    :color="item.color"
                    class="py-n12 text-overline"
                    >{{ item.title }}
                  </v-list-item-title>
                </v-list-item-content>
              </div>
            </template>

            <!-- Child -->
            <div v-if="item.child">
              <v-list-item
                v-for="(subItem, i) in item.child"
                :key="i"
                link
                :to="subItem.route"
                color="secondary"
                class="mt-n4"
              >
                <v-list-item-title
                  :color="subItem.color"
                  class="ml-7 primary--text text-overline"
                >
                  {{ subItem.title }}
                </v-list-item-title>
                <v-list-item-icon>
                  <v-icon :color="subItem.color">{{ subItem.icon }}</v-icon>
                </v-list-item-icon>
              </v-list-item>
            </div>
          </v-list-group>
          <!-- if no children -->
          <v-list-item
            v-else-if="!item.child"
            link
            :to="item.route"
            :class="mini ? 'py-n12 mt-2' : 'py-n15'"
            color="secondary"
          >
            <v-list-item-icon>
              <v-btn
                :color="item.color"
                fab
                dark
                small
                class="my-n2 ml-n2"
                v-if="mini"
              >
                <v-icon color="white">{{ item.icon }}</v-icon>
              </v-btn>
              <v-btn :color="item.color" fab small dark class="my-auto" v-else>
                <v-icon color="white">{{ item.icon }}</v-icon>
              </v-btn>
            </v-list-item-icon>

            <v-list-item-content class="primary--text">
              <v-list-item-title :color="item.color" class="text-overline">{{
                item.title
              }}</v-list-item-title>
            </v-list-item-content>
          </v-list-item>
        </v-list>
      </v-navigation-drawer>

      <!-- AppBar -->
      <v-app-bar class="light-blue" color="darken-1" dense clipped-left app>
        <div :class="mini ? 'ml-n2' : ''">
          <v-app-bar-nav-icon
            @click.stop="(mini = !mini), (groupOpened = false)"
            color="grey lighten-4"
          ></v-app-bar-nav-icon>
        </div>
        <div class="white--text caption" v-if="!mini">
          <span>{{ companyName }}</span>
        </div>

        <v-spacer></v-spacer>
        <v-menu max-width="300px" left bottom offset-y>
          <template v-slot:activator="{ on, attrs }">
            <v-btn icon v-bind="attrs" v-on="on">
              <v-icon color="white">mdi-cog-outline</v-icon>
            </v-btn>
          </template>
          <v-list>
            <v-list-item><span>Manage Dashboard</span></v-list-item>
          </v-list>
        </v-menu>
      </v-app-bar>
    </div>
    <div :class="mini ? 'mx-7 mt-4' : 'mx-7 mt-5'">
      <router-view></router-view>
    </div>
    <FooterComponentVue />
  </v-app>
</template>

<script>
import FooterComponentVue from "./FooterComponent.vue";

export default {
  name: "layoutBar",
  components: { FooterComponentVue },
  data: () => ({
    drawer: true,
    companyName: "ABC Property Management",
    groupOpened: false,
    mini: false,
    adminMenu: [
      {
        title: "Dashboard",
        icon: "mdi-view-dashboard ",
        route: "/",
        color: "primary",
      },
      {
        title: "File Module",
        icon: "mdi-file-multiple",
        route: "/file",
        color: "primary",
        child: [
          {
            title: "Files",
            icon: "mdi-file-multiple",
            route: "/files",
            color: "primary",
          },
          {
            title: "Configurations",
            icon: "mdi-account-group",
            route: "/subscriber-config",
            color: "primary",
          },
        ],
      },
      {
        title: "DocuSign",
        icon: "mdi-signature-freehand ",
        route: "/sign",
        color: "primary",
        child: [
          {
            title: "Shared Docs",
            icon: "mdi-share-outline ",
            route: "/shared",
            color: "primary",
          },
          {
            title: "Signatures",
            icon: "mdi-signature-freehand ",
            route: "/sign",
            color: "primary",
          },
          {
            title: "Share Doc",
            icon: "mdi-share ",
            route: "/share-doc",
            color: "primary",
          },
        ],
      },
    ],
  }),
};
</script>
<style scoped>
.v-navigation-drawer >>> .v-navigation-drawer__border {
  display: none;
}
.v-responsive__content {
  overflow-y: auto;
}
</style>
