<template>
<!-- FOOTER -->
  <v-footer color="secondary" fixed value="false" app>
    <v-col cols="12">
      <div class="d-flex justify-center mt-5 ml-15">
        <span class="text-caption primary--text mt-n5 ml-15"
          >{{ this.currentYear }} - &copy; Property Design & Develop by Property.</span
        >
      </div>
    </v-col>
  </v-footer>
</template>

<script>
export default {
  data: () => ({
    currentYear: new Date().getFullYear(),
  }),
};
</script>
