<template>
  <div class="pdf-container"></div>
</template>

<script>
import PSPDFKit from "pspdfkit";
import FileService from "@/service/file.service";

export default {
  name: "PSPDFKit",
  props: {
    // PDF file prop
    pdfFile: {
      type: String,
      required: true,
    },
  },

  data: () => ({
    editedItem: {
      id: "",
      documentId: "",
      prospectEmail: "",
      signature: "",
    },

    defaultItem: {
      id: "",
      documentId: "",
      prospectEmail: "",
      signature: "",
    },
  }),

  mounted() {
    // load the document instance
    this.loadPSPDFKit().then((instance) => {
      this.$emit("loaded", instance);
    });
  },

  watch: {
    // watch of the prop changes to load and unload document
    pdfFile(val) {
      if (val) {
        this.loadPSPDFKit();
      }
    },
  },

  methods: {
    // this method loads and unload the document
    async loadPSPDFKit() {
      PSPDFKit.unload(".pdf-container");
      return PSPDFKit.load({
        // access the file from props
        document: this.pdfFile,
        container: ".pdf-container",
        licenseKey: "",
        instantJson: null,
        instant: true,
      }).then((instance) => {
        // save Annotations
        instance.addEventListener("annotations.create", () => {
          instance.exportInstantJSON().then((newAnnotation) => {
            this.editedItem.documentId = 1;
            this.editedItem.prospectEmail = "mikenzioki65@gmail.com";
            this.editedItem.signature = newAnnotation.annotations;
            console.log(this.editedItem, 'the itemmm')

            FileService.addAnnotations(this.editedItem).then((response) => {
              if (response.status === 200) {
                this.$store.dispatch("alert/success", response.data.message);
                this.getDocuSign();
                this.loading = false;
                this.close();
              } else {
                this.$store.dispatch(
                  "alert/error",
                  "Invalid data, please check the form try again!"
                );
                this.loading = false;
              }
              (error) => {
                if (error.response.status === 422) {
                  this.$store.dispatch(
                    "alert/error",
                    error.response.data.message
                  );
                }
                this.$store.dispatch(
                  "alert/error",
                  error.response.data.message
                );
                this.loading = false;
              };
            });
          });

          // Delete Annotations
          instance.addEventListener(
            "annotations.delete",
            (deletedAnnotations) => {
              console.log(deletedAnnotations, 'the deleted');
            }
          );
        });
      });
    },
  },

  beforeUnmount() {
    // clean up when the doc is unmounted to load another one
    PSPDFKit.unload(".pdf-container");
  },
};
</script>

<style>
.pdf-container {
  height: 91vh;
}
</style>