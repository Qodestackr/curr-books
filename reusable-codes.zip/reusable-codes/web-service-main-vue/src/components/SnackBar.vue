<template>
  <div>
    <v-snackbar
      v-model="snackbar"
      :timeout="-1"
      :value="true"
      absolute
      bottom
      :color="snackbarColor"
      outlined
      right
    >
      {{ snackbarMessage }}
    </v-snackbar>
  </div>
</template>

<script>
import Swal from "sweetalert2";

export default {
  name: "SnackBar",
  data: () => ({
      snackbar: false,
      color: 'success',
      icon: 'mdi-check',
  }),
  methods: {
    hideSnackbar() {
      this.$store.dispatch("alert/clear");
    },
    
    showSnackBar() {
      Swal.fire({
        icon: this.snackbarColor,
        title: this.snackbarMessage,
        iconColor: '#30a702',
        timer: 1500,
      }).then(this.hideSnackbar());
      // this.snackbar = true;
      // this.hideSnackbar();
    },
  },

  watch: {
    snackbarShow() {
      if (this.snackbarShow == true) {
        this.showSnackBar();
      }
    },
    snackbarMessage() {
      return this.$store.state.auth.snackbar.message;
    },
    snackbarColor() {
      return this.$store.state.auth.snackbar.color;
    },
  },
  computed: {
    snackbarShow: {
      get() {
        return this.$store.state.auth.snackbar.show;
      },
      set() {
        this.$store.dispatch("auth/clearSnack");
      },
    },
    snackbarMessage() {
      return this.$store.state.auth.snackbar.message;
    },
    snackbarColor() {
      return this.$store.state.auth.snackbar.color;
    },
  },
};
</script>
