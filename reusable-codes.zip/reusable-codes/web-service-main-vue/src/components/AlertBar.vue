<template>
  <div></div>
</template>

<script>
import Swal from "sweetalert2";

export default {
  name: "AlertBar",
  methods: {
    hideAlert() {
      this.$store.dispatch("alert/clear");
    },
    showAlert() {
      Swal.fire({
        icon: this.color,
        title: this.message,
        timer: 1500,
      }).then(this.hideAlert());
    },
  },

  watch: {
    alert() {
      if (this.alert == true) {
        this.showAlert();
      }
    },
    message() {
      return this.$store.state.alert.message;
    },
    color() {
      return this.$store.state.alert.color;
    },
  },

  computed: {
    alert: {
      get() {
        return this.$store.state.alert.show;
      },
      set() {
        setTimeout(() => {
          this.$store.dispatch("alert/clear");
        }, 3000);
      },
    },
    message() {
      return this.$store.state.alert.message;
    },
    color() {
      return this.$store.state.alert.color;
    },
  },
};
</script>
<style>
.swal2-confirm {
  background-color: red !important;
  border-color: #dd6b55;
  box-shadow: none;
}
</style>