import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import vuetify from './plugins/vuetify'
import * as firebase from "firebase/app";

Vue.config.productionTip = false
const firebaseConfig = {
  apiKey: "AIzaSyCnlA3rLSKV_6k3AHj8lAgDtA5LanUJL58",
  authDomain: "pmsmaadeez.firebaseapp.com",
  projectId: "pmsmaadeez",
  storageBucket: "pmsmaadeez.appspot.com",
  messagingSenderId: "236182363398",
  appId: "1:236182363398:web:225e2187774d9a3bc19287",
  measurementId: "G-YRTF8YBMP6"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
console.log(firebase,'fire')

new Vue({
  router,
  store,
  vuetify,
  render: h => h(App)
}).$mount('#app')
