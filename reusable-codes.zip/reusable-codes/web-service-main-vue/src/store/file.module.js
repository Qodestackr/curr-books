const initialState = {
    selected_file: {},
};

export const file = {
    namespaced: true,
    state: initialState,
    actions: {
        setSelectedFile({ commit }, item) {
            commit('setSelectedFile', item)
        },
    },
    mutations: {
        setSelectedFile(state, item) {
            state.selected_file = item
        },

    }
};