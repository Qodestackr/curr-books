const initialState = {
    selected_email: {},
    reset_user_id: {},
};

export const auth = {
    namespaced: true,
    state: initialState,
    actions: {
        setSelectedEmail({ commit }, item) {
            commit('setSelectedEmail', item)
        },

        setuserId({ commit }, item) {
            commit('setuserId', item)
        },
    },
    mutations: {
        setSelectedEmail(state, item) {
            state.selected_email = item
        },

        setuserId(state, item) {
            state.reset_user_id = item
        },

    }
};