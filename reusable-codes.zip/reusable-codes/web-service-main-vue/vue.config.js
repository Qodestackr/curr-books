const { defineConfig } = require('@vue/cli-service')

const isProduction = process.env.NODE_ENV === 'production'
const isStaging = process.env.NODE_ENV === 'staging'

module.exports = defineConfig({
    transpileDependencies: [
        'vuetify'
    ],

    devServer: {
        proxy: {
            '^/api': {
                target: 'http://localhost:9191',
                changeOrigin: true,
                logLevel: 'debug',
                pathRewrite: { '^/api': '/api' },
            },
        },
    },
    publicPath: isProduction ? 'https://web.sqftmanagement.com/web/' : isStaging ? 'https://web.pmsmadeez.com/web/' : './',

})