import pandas as pd
def parse_GeoJson(source, options=None):
    if source:
        gis_json_df = pd.read_json(source)
        return gis_json_df
    else:
        return {}
def parse_shapefiles(source, options=None):
    pass
