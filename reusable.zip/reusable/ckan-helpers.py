## def get_geox-data-portal_themes
## get_iso_topic_categories
## get_default_spatial_search_extent

## convert_geojson_to_bbox => MORE WORK

import typing #noqa

def helper_show_version(*args, **kwargs) -> typing.Dict:
    return show_version()


'''
@toolkit.side_effect_free
def show_version(
        context: typing.Optional[typing.Dict] = None,
        data_dict: typing.Optional[typing.Dict] = None,
) -> typing.Dict:
    """return the current version of this project"""
    return {
        "version": pkg_resources.require("ckanext-saeoss")[0].version,
        "git_sha": os.getenv("GIT_COMMIT"),
    }

'''

## user_is_org_member
## user_is_staff_member
## org_member_list


'''
def get_featured_datasets():
    search_action = toolkit.get_action("package_search")
    result = search_action(data_dict={"q": "featured:true", "rows": 5})
    return result["results"]
'''


'''
def get_all_datasets_count(user_obj):
    """
    fixes a bug when applying
    solr active search

    """
    # context = {"user":c.user, "auth_user_obj":c.userobj}
    # return len(packages)
    # 32000 rows is the maximum of what can be retrieved
    # by ckan at once.
    # the question becomes, do i want you to know the private datasets count ?
    # q = """ select count(distinct(id)) from package where state='active' and type='dataset' """
    # result = model.Session.execute(q)
    # return result.fetchone()[0]

    # this doesn't work
    # results = toolkit.get_action("package_list")(context={"auth_user_obj": c.userobj}, data_dict={'include_private':True})

    result = toolkit.get_action("package_search")(
        data_dict={"q": "*:*", "include_private": True}
    )
    return result["count"]

'''


'''
def get_org_public_records_count(org_id: str) -> int:
    """
    the default behavior is showing fixed
    number of recoreds for orgs if the
    user is not a part of them in org
    list page, we are adjusting
    """
    query = model.Session.query(model.Package).filter(
        model.Package.owner_org == org_id,
        model.Package.private == "f",
        model.Package.state == "active",
        model.Package.type == "dataset",
    )
    count = len(query.all())
    return count

'''


'''
def _pad_geospatial_extent(extent: typing.Dict, padding: float) -> typing.Dict:
    geom = geometry.shape(extent)
    padded = geom.buffer(padding, join_style=geometry.JOIN_STYLE.mitre)
    oriented_padded = geometry.polygon.orient(padded)
    return geometry.mapping(oriented_padded)


def get_org_memberships(user_id: str):
    """Return a list of organizations and roles where the input user is a member"""
    query = (
        model.Session.query(model.Group, model.Member.capacity)
        .join(model.Member, model.Member.group_id == model.Group.id)
        .join(model.User, model.User.id == model.Member.table_id)
        .filter(
            model.User.id == user_id,
            model.Member.state == "active",
            model.Group.is_organization == True,
        )
        .order_by(model.Group.name)
    )
    return query.all()

'''
















def get_today_date() -> str:
    return datetime.datetime.now().strftime("%Y-%m-%d")


def get_current_release():
    """get releases to website footer,
    the release depends on the environment,
    if it's staging it uses v*.*.*-rc, rather
    if it's production v.*.*.*
    """
    current_file_path = Path(__file__)
    releases_file_path = current_file_path.parent.joinpath("releases.txt")
    with open(releases_file_path) as f:
        releases = json.loads(f.read())
        current_branch = _get_git_branch()
        # this might change so main is release candidate
        # and release branch is the latest release
        if current_branch == "development":
            return releases.get("latest_release_candidate")
        elif current_branch == "main":
            return releases.get("latest_release")
        else:
            return ""


def _get_git_branch():
    """Getting the current branch name.

    """
    return "development"


def get_saved_searches():
    """Returns saved searches

    based on a user id.
    """
    if c.userobj is None:
        return []

    user_id = c.userobj.id
    if c.userobj.sysadmin:
        q = f""" select saved_search_title, search_query, saved_search_date, saved_search_id, owner_user from saved_searches order by owner_user """
    else:
        q = f""" select saved_search_title, search_query, saved_search_date, saved_search_id from saved_searches where owner_user='{user_id}' order by saved_search_date desc """
    rows = model.Session.execute(q)
    saved_searches_list = []
    for row in rows:
        saved_searches_list.append(row)
    # saved_searches_list = SavedSearches.get(SavedSearches,owner_user=user_id)
    return saved_searches_list


def get_user_name(user_id):
    """Get a user's username by its id

    :param
    user_id: User's id
    :type
    user_id:int
    """
    user_obj = model.Session.query(model.User).filter_by(id=user_id).first()
    return user_obj.name


def get_user_id(user_name: str):
    """Gets user id from its username (the username is also unique)

    :param
    user_name: User's username
    :type
    user_name:str
    """
    user_obj = model.Session.query(model.User).filter_by(name=user_name).first()
    return user_obj.id


def get_user_name_from_url(url: str):
    """Get user's name from url

    :param
    url: The url
    :type
    url:str
    """

    return url.split("/user/")[1]


def get_recent_news(number=5, exclude=None):
    """Get the five recent news.

    :param
    number: Number of new want to get
    :type
    number: int
    """
    news_list = toolkit.get_action("ckanext_pages_list")(
        None, {"order_publish_date": True, "private": False, "page_type": "news"}
    )
    new_list = []
    for news in news_list:
        if exclude and news["name"] == exclude:
            continue
        new_list.append(news)
        if len(new_list) == number:
            break

    return new_list


def get_seo_metatags(site_key):
    """Get metatags value for SEO.

    :param
    site_key: Site's key
    :type
    site_key: str
    """
    data_dict = {
        "site_author": toolkit.config.get(
            "ckan.site_author",
        ),
        "site_description": toolkit.config.get(
            "ckan.site_description",
        ),
        "site_keywords": toolkit.config.get(
            "ckan.site_keywords",
        ),
    }
    return data_dict[site_key]


def get_year():
    """Display current year in the footer.

    """
    return datetime.datetime.now().year


def get_user_dashboard_packages(user_id):
    """The current behavior displays
    all the available datasets to the
    user, we need only the datasets
    created by the user.

    :param
    user_id: User's id
    :type
    user_id: int
    """
    # q = f""" select package.*, key, value from package join package_extra on package_id=package.id where
    # package.creator_user_id='{user_id}' """ rows = model.Session.execute(q) packages = [] for row in rows:
    # packages.append(dict(row)) return packages
    query = model.Session.query(model.Package).filter(
        model.Package.creator_user_id == user_id
    )
    packages = [
        package_dictize(package, context={"user": user_id, "model": model})
        for package in query.all()
    ]
    return packages

