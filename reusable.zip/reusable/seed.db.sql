-- Create tables for transit data
CREATE TABLE transit_stops (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100),
    location GEOMETRY(Point, 4326)
);

CREATE TABLE routes (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100),
    description TEXT,
    route_path GEOMETRY(LineString, 4326)
);

CREATE TABLE fares (
    id SERIAL PRIMARY KEY,
    route_id INT REFERENCES routes(id),
    fare_amount NUMERIC(10, 2),
    currency VARCHAR(3)
);

-- User management tables
CREATE TABLE transit_users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(128) NOT NULL,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    email VARCHAR(100)
);

CREATE TABLE user_bookmarked_routes (
    id SERIAL PRIMARY KEY,
    user_id INT REFERENCES transit_users(id),
    route_id INT REFERENCES routes(id),
    bookmarked_on TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE user_ratings (
    id SERIAL PRIMARY KEY,
    user_id INT REFERENCES transit_users(id),
    route_id INT REFERENCES routes(id),
    rating INT CHECK (rating >= 1 AND rating <= 5),
    review TEXT,
    rated_on TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Transit alerts
CREATE TABLE transit_alerts (
    id SERIAL PRIMARY KEY,
    route_id INT REFERENCES routes(id),
    alert_message TEXT,
    alert_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Geospatial data for locations
CREATE TABLE locations (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100),
    location GEOMETRY(Point, 4326)
);

-- Insert sample locations
INSERT INTO locations (name, location)
VALUES
    ('Location A', ST_GeomFromText('POINT(-122.123456 47.987654)', 4326)),
    ('Location B', ST_GeomFromText('POINT(-122.987654 47.123456)', 4326));

-- Transit usage statistics
CREATE TABLE transit_usage_statistics (
    id SERIAL PRIMARY KEY,
    date DATE,
    daily_users INT,
    weekly_users INT,
    monthly_users INT
);

-- User activity log
CREATE TABLE user_activity_log (
    id SERIAL PRIMARY KEY,
    user_id INT REFERENCES transit_users(id),
    action VARCHAR(50),
    action_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Real-time tracking data
CREATE TABLE vehicle_tracking (
    id SERIAL PRIMARY KEY,
    vehicle_id INT,
    location GEOMETRY(Point, 4326),
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Data Aggregation and Reporting (Materialized View Example)
-- summarize transit alerts by route, indicating the total number 
-- of alerts, resolved alerts, and unresolved alerts.
CREATE MATERIALIZED VIEW transit_alert_summary AS
SELECT
    route_id,
    COUNT(*) AS total_alerts,
    COUNT(CASE WHEN resolved_status = true THEN 1 END) AS resolved_alerts,
    COUNT(CASE WHEN resolved_status = false THEN 1 END) AS unresolved_alerts
FROM transit_alerts
GROUP BY route_id;


--------------------------------------
--------------------------------------
-- Your Gateway to Greener, Data-First Solutions for Spatial Intelligence
-- High Availability Data Portal for Analytics in East and South of Africa.
--------------------------------------
--------------------------------------