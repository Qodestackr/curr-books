#!/bin/bash

# Check and clean up failed containers
function cleanup_containers {
  echo "Checking and cleaning up failed containers..."
  failed_containers=$(docker ps -aq -f status=exited)

  if [ -n "$failed_containers" ]; then
    docker rm -v $failed_containers
  else
    echo "No failed containers found."
  fi
}

# Clean up unused Docker images and cache
function cleanup_images {
  echo "Cleaning up unused Docker images and cache..."
  docker image prune -af
  docker builder prune -af
}

function main {
  cleanup_containers
  cleanup_images
}

# Run the script
main
