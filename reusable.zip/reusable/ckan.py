# pip install ckanapi vs pip install ckan
import ckan.plugins.toolkit as toolkit
from pprint import pprint
import json
import pandas as pd
import requests
import ckanapi

from ckan.exceptions import (
    CkanUrlException,
    CkanException,
    CkanDeprecationWarning,
    CkanVersionException,
    CkanConfigurationException,
)

ckanapi.RemoteCKAN
# base_url = 'api/action/'
# call_action
# _request_fn
# _request_fn_get
# close
# __enter__
# __exit__

ckanapi.CKANAPIError
ckanapi.LocalCKAN
"""
LocalCKAN: An interface to calling actions with get_action() for CKAN plugins.

:param username: perform action as this user, defaults to the site user
            and stored as self.username
:param context: a default context dict to use when calling actions,
            stored as self.context with username added as its 'user' value

METHODS: get_site_username, call_action, 

"""

ckanapi.NotAuthorized
ckanapi.NotFound
ckanapi.SearchError
ckanapi.SearchIndexError
ckanapi.SearchQueryError
ckanapi.ValidationError
ckanapi.ServerIncompatibleError

ckanapi.TestAppCKAN
"""
An interface to the the CKAN API actions on a paste TestApp
:param test_app: the paste.fixture.TestApp instance, stored as
                self.test_app
:param apikey: the API key to pass as an 'X-CKAN-API-Key' header
                when actions are called, stored as self.apikey

METHODS: call_action, 
"""


ckanapi.__annotations__
ckanapi.__builtins__
ckanapi.__cached__
ckanapi.__dict__
ckanapi.__doc__
ckanapi.__file__
ckanapi.__loader__
ckanapi.__name__
ckanapi.__package__
ckanapi.__path__
ckanapi.__qualname__
ckanapi.__spec__


##############################################################################
# ckan.common._
# ckan.lib.base.abort
# ckan.lib.helpers
# ckan.logic
# ckan.logic.get_action
# ckan.model
# ckan.model.Package
# ckan.model.Package.get
# ckan.model.Resource
# ckan.model.Session
# ckan.model.Session.query
# ckan.plugins
# ckan.plugins.implements
# ckan.plugins.toolkit
# ckan.plugins.toolkit._
# ckan.plugins.toolkit.abort
# ckan.plugins.toolkit.check_access
# ckan.plugins.toolkit.get_action
# ckan.plugins.toolkit.render
# ckan.plugins.toolkit.ValidationError

# ckanext.datapackager.logic.action.create
# ckanext.datapackager.logic.action.get
# ?from pylons import config
# *json.dumps, requests, pandas


###########
# Package list of the Swiss open data portal
packages = 'https://opendata.swiss/api/3/action/package_list'
# Make the HTTP request
response = requests.get(packages)

# Use the json module to load CKAN's response into a dictionary
response_dict = json.loads(response.content)

# Check the contents of the response
assert response_dict['success'] is True  # make sure if response is OK
# extract all the packages from the response
datasets = response_dict['result']
print(len(datasets))                       # print the total number of datasets


# We can print the last 10 to the screen to get an idea of the titles:
datasets[-10:]
##############################################################################


# Specify the package you are interested in:
package = 'bruttoinlandprodukt'
# Now let's download the package/dataset information. We need to take a few steps:

# Base url for package information. This is always the same.
base_url = 'https://opendata.swiss/api/3/action/package_show?id='

# Construct the url for the package of interest
package_information_url = base_url + package

# Make the HTTP request
package_information = requests.get(package_information_url)

# Use the json module to load CKAN's response into a dictionary
package_dict = json.loads(package_information.content)

# Check the contents of the response.
assert package_dict['success'] is True  # again make sure if response is OK
# we only need the 'result' part from the dictionary
package_dict = package_dict['result']

# pprint.pprint(package_dict)           # pretty print the package information to screen


# Get the url for the data from the dictionary
data_url = package_dict['resources'][0]['url']
print('Data url:     ' + data_url)

# Print the data format
data_format = package_dict['resources'][0]['format']
print('Data format:  ' + data_format)

"""Data url:     https://github.com/StataBS/indikatoren/tree/master/data/4323.tsv
Data format:  TSV
Notice that this particular dataset is hosted at GitHub. When downloading from GitHub, it is better to request the raw data. 
We need to rewrite the URL a little bit to get there."""

# If data is hosted at GitHub, always download the raw data
if data_url.startswith('https://github.com/'):
    data_url = data_url.replace(
        'https://github.com/', 'https://raw.githubusercontent.com/')
    data_url = data_url.replace('tree/', '')
print('Data url:     ' + data_url)
"""Data url:     https://raw.githubusercontent.com/StataBS/indikatoren/master/data/4323.tsv
Feel free to take a follow the URL's bove. It is good to take a sneak peak so you know what the data will look like. 
The dataset can come in different formats, so let's specify which ones we are willing to accept and load them into a 
Pandas DataFrame."""

# List of formats we work with in this exercise
csv = ['comma-separated-values', 'CSV', 'csv']
tsv = ['tab-separated-values', 'TSV', 'tsv']
xls = ['XLS']


# Download the data to a Pandas DataFrame. Use seperate function calls, depending on the format of the dataset.
if any(s in data_format for s in csv):     # pd.read_csv()
    df = pd.read_csv(data_url)
elif any(s in data_format for s in tsv):   # pd.read_csv() and specify the delimiter
    df = pd.read_csv(data_url, sep='\t')
elif any(s in data_format for s in xls):   # pd.read_excel()
    df = pd.read_excel(data_url)
else:
    print('Sorry, the data format is not supported for this exercise')

# Print the first rows to the screen to inspect the dataset
df.head(5)


############################################
############################################
# As you can see, we need to make a few adjustments before we can continue. It is best to clean up the dataset before you
# start doing your analysis.

# Remove the column 'DateTime', because it is empty
df.drop('DateTime', axis=1, inplace=True)

# Make 'Jahr' the index
df.set_index('Jahr', inplace=True)
# That's it! Now let's visualise the data with Pandas built-in plot functionality, which is based on 'matplotlib'.

# Use IPython's "magic" in Jupyter Notebook to directly show the plot on the screen.
# %matplotlib inline
df.plot()


############################################

# @https://docs.ckan.org/en/2.9/extensions/index.html
# @https://docs.ckan.org/en/2.9/extensions/best-practices.html
# @https://docs.ckan.org/en/2.9/maintaining/configuration.html#ckan-plugins
# @https://lwbin-dev.ad.umanitoba.ca/content/accessing-ckans-data-api-using-pythonv

############################################


########################################################################################
########################################################################################


# API endpoint
url = 'https://lwbin-dev.ad.umanitoba.ca/data/api/3/action/datastore_search?resource_id=c5c16064-e2b3-4618-9b27-0dbf5c1388c2'

# To make a ‘GET’ request, we’ll use the requests.get() function, which requires one argument — the URL we want to make the request to.
response = requests.get(url)

# The get() function returns a response object. We can use the response.status_code attribute to receive the status code for our request.
# Code - 200: Everything went okay, and the result has been returned (if any).
print(response.status_code)

# JSON (JavaScript Object Notation) is the language of APIs. JSON is a way to encode data structures that ensures that they are easily readable by machines.
# JSON is the primary format in which data is passed back and forth to APIs, and most API servers will send their responses in JSON format.

# Use the response.json() method to see the data we received back from the API as a dictionary
response_data = response.json()
# print(response_data)

# To get the data records. 'data' is now a list, containing each line of data as a dictonary.
data = response_data['result']['records']

# To see a list of all the column headers
col_headers = data[0].keys()

# If we want to filter the data, for example, we only want Cast=3.
filtered_data = list(filter(lambda row: row['Cast'] == '3', data))

# Output data as a dataframe for easy manipulation
df1 = pd.DataFrame(data)
df2 = pd.DataFrame(filtered_data)

# Save to csv file
df1.to_csv('output.csv', index=False)


# To get more metadata
# dataDump = json.dumps(response_data, sort_keys=True, indent=4)
# print(dataDump)
########################################################################################
########################################################################################


# @@http://docs.ckan.org/en/latest/maintaining/datastore.html#ckanext.datastore.logic.action.datastore_search
"""
Adding more functionality directly in the datasetore_search action call
To add more parameters to the query, use an & before each parameter pair (key=value) after the resource id. 
For example, to get the first two rows of data only add &limit=2 after the resource id. See all parameters here.
"""

# Filtering the data
# Format: &filters={"key":"value"}


# filters (dictionary)

# Filtering only the data records where Cast=3 and sample_date=2016-06-09T00:00:00

url = 'https://lwbin-dev.ad.umanitoba.ca/data/api/3/action/datastore_search?resource_id=c5c16064-e2b3-4618-9b27-0dbf5c1388c2&filters={"Cast":"3","sample_date":"2016-06-09T00:00:00" }'

response = requests.get(url)
response_data = response.json()
data = response_data['result']['records']

df1 = pd.DataFrame(data)
df1

# Limiting the data returned
# Format: &limit=3


# limit (integer)

# limit=2 , only the first two rows
url = 'https://lwbin-dev.ad.umanitoba.ca/data/api/3/action/datastore_search?resource_id=c5c16064-e2b3-4618-9b27-0dbf5c1388c2&limit=2'

response = requests.get(url)
response_data = response.json()
data = response_data['result']['records']

df1 = pd.DataFrame(data)
df1


#####################################################
# @@RETURNING ALL DATA FROM A CKAN API REQUEST:
"""http://docs.ckan.org/en/latest/maintaining/datastore.html#ckanext.datastore.logic.action.datastore_search"""


"""
There are several interesting fields in the documentation for ckanext.datastore.logic.action.datastore_search(), 
but the ones that pop out are limit and offset.

limit seems to have an absolute maximum of 32000 so depending on the amount of data you might still hit this limit.

offset seems to be the way to go. You keep calling the API with the offset increasing by a set amount until you have 
all the data. See the code below.

But, actually calling the API revealed something interesting. It generates a next URL which you can call, it 
automagically updates the offset based on the limit used (and maintaining the limit set on the initial call).
You can call this URL to get the next batch of results.

Some testing showed that it will go past the maximum though, so you need to check if the returned records are lower 
than the limit you use.
"""


BASE_URL = "https://data.gov.au/data"
INITIAL_URL = "/api/3/action/datastore_search?resource_id=d54f7465-74b8-4fff-8653-37e724d0ebbb"
LIMIT = 10000


def get_all() -> list:
    result = []
    resp = requests.get(f"{BASE_URL}{INITIAL_URL}&limit={LIMIT}")
    js = resp.json()["result"]
    result.extend(js["records"])
    while "_links" in js and "next" in js["_links"]:
        resp = requests.get(BASE_URL + js["_links"]["next"])
        js = resp.json()["result"]
        result.extend(js["records"])
        # just so you know it's actually doing stuff
        print(js["_links"]["next"])
        if len(js["records"]) < LIMIT:
            # if it returned less records than the limit, the end has been reached
            break
    return result


print(len(get_all()))


"""There are several interesting fields in the documentation for ckanext.datastore.logic.action.datastore_search(), 
but the ones that pop out are limit and offset.

limit seems to have an absolute maximum of 32000 so depending on the amount of data you might still hit this limit.

offset seems to be the way to go. You keep calling the API with the offset increasing by a set amount until you have 
all the data. See the code below.

But, actually calling the API revealed something interesting. It generates a next URL which you can call, it automagically 
updates the offset based on the limit used (and maintaining the limit set on the initial call).
You can call this URL to get the next batch of results.

Some testing showed that it will go past the maximum though, so you need to check if the returned records are lower than the 
limit you use.
"""


BASE_URL = "https://data.gov.au/data"
INITIAL_URL = "/api/3/action/datastore_search?resource_id=d54f7465-74b8-4fff-8653-37e724d0ebbb"
LIMIT = 10000


def get_all() -> list:
    result = []
    resp = requests.get(f"{BASE_URL}{INITIAL_URL}&limit={LIMIT}")
    js = resp.json()["result"]
    result.extend(js["records"])
    while "_links" in js and "next" in js["_links"]:
        resp = requests.get(BASE_URL + js["_links"]["next"])
        js = resp.json()["result"]
        result.extend(js["records"])
        # just so you know it's actually doing stuff
        print(js["_links"]["next"])
        if len(js["records"]) < LIMIT:
            # if it returned less records than the limit, the end has been reached
            break
    return result


print(len(get_all()))
"""Note, when exploring an API, it helps to check what exactly is returned. I used the simple 
code below to check what was returned, which made exploring the API a lot easier. 
Also, reading the docs helps, like the one I linked above."""
pprint(requests.get(BASE_URL+INITIAL_URL+"&limit=1").json()["result"])

######################################################


## https://snyk.io/advisor/python/ckan/functions/ckan.plugins
## https://docs.ckan.org/en/2.9/maintaining/configuration.html#ckan-plugins
## https://docs.ckan.org/en/2.10/extensions/tutorial.html
## https://docs.ckan.org/en/2.9/maintaining/configuration.html#ckan-configuration-file
## https://musaamin.web.id/how-to-install-ckan-open-data-portal-ubuntu2004/
## https://medium.com/mcd-unison/mastering-data-management-with-ckan-api-and-python-f63419791c98


##!!!!!!!!!!!!!! https://docs.tethysplatform.org/en/stable/tethys_sdk/tethys_services/dataset_service/ckan_reference.html

##!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
##@@ https://anant.us/blog/modern-business/open-source-data-catalog-overview-ckan/
##!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


from ckan.logic import (  # noqa: re-export
    get_action,
    check_access,
    get_validator,
    chained_auth_function,
    chained_action,
    NotFound as ObjectNotFound,
    NotAuthorized,
    ValidationError,
    UnknownValidator,
    get_or_bust,
    side_effect_free,
    auth_sysadmins_check,
    auth_allow_anonymous_access,
    auth_disallow_anonymous_access,
    fresh_context,
)