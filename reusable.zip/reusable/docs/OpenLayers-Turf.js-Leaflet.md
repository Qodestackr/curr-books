Leaflet
Open Layers
Turf.js

<!--
* Geopandas-leaflet: Python lib to viz Geopandas GeoDataFrame on interactive Leaflet maps

* GDAL * org2org: Geospatial Data Abstraction Library. Org2Org=> CLI tool for working with
various data formats, converting between them, and performing geospatial operations
-->


Turf.js: Expects GeoJSON
An advanced library ti perform Node/ Browser geospatial analysis

Numerous spatial functions for buffering, distance calculations. intersections, unions, and more


Open layers: Feature-rich mapping library with capabilities for creating dynamic and interactive maps
Supports map projections, vector data, raster tiles, custom styling options
<!-- 
TODO: Know how to treat data. It has coordinates and hence map it with custom icon or whatever on a map

Click or interactions to provide more insights

Which data works best with browser and maps?

:OpenLayers for complex spatial operations and suitable for projects that need advanced GIS functionalities

-->



## Using OpenLayers and Leaflet together
1. Fallback mechanism: If WebGL is not supported in user's browser or you maintain a list of device type
from user and if not powerful enough, use Leaflet instead
2. Specialized UseCases and diff Map Layers...
<!-- Open layers=> custom vector data
Leaflet => standard raster tiles


*React-leaflet
*React-OpenLayers
*Kerpler/Deck.gl


Geospatial data services: Mapbox, HERE, Google Maps for access to pre-defined map tiles and other map data
 -->