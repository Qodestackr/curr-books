1. Setup DRF + django-rest-knox(token auth)
2. API Key for each provider(Google, Gitlab, GitHub)
   => Define URL callbacks
3. Endpoints for registration and login
4. Implement API key gen for authenticated users
   => end point to gen API key after first-login and new ones if user needs to
   => Store them on a database

# Frontend

1. React app with social auth buttons
2. Add logic for backend API/ network calls(SWR/ React Query/ with Axios)
3. Handle auth redirects if needed(to respective provider's login page)
4. Recieve auth callback from social providers & handle it in the frontend

- Extract necessary data(e.g access tokens) from callback URL and send to backend to
  complete social auth process

## The Flow

- User visits the client app and sees options to regsiter: SSO
- User clicks one of SSO buttons
- Client app redirects to respective social auth login page
- User logs in using their social auth provider's credentials
- After successful login, social auth provider redirects user back to frontend app
  along with necessary data(tokens)
- React app sends them to backend API to complete authentication process
  (<!--Any security risk to intercept them?-->)
- Backend verifies the token
  How? Does it reach to make network call to the provider or SDKs can handle that offline?

If verification is successfull, the backend will register user or log them in, if new or existing

- Backend gens new API key for the user and sends it back to the React frontend
<!-- User now logged in and has an API key to access protected resources -->
