# Real-time solution
Time series data

Apache Kafka for event processing


On Cloud data lake


Innovative real-time data integration and streaming platform/pipelines


Products:
- Cloud:A fully managed SaaS solution that enables infinitely scalable unified data integration and streaming.
Cloud means the service if fully managed on multiple cloud platforms : AWS, GCP, Azure
- ProductX for bigquery, for snowflake, for databricks, etc

Data Mesh
Real Time Operations
Data Modernization
Digital Customer Experience
Data Fabric
Real-Time Analytics


1. Connect Data Sources and Targets: connect to your sources with a point and click wizard. Select tables, migrate schemas, and start moving data in seconds.
2. Intelligent Schema Evolution: have full control whenever data drifts. Capture schema changes, configure how each consumer propagates the change or simply 
halt and alert when a manual resolution is needed.
3. 


# Features
1. Data connectors to other enterprise sources
2. Data freshness
Stale batch data can cost you a customer. Fresh data guarantees the latest insights on operational data to make profitable real-time decisions.
3. Scalability and throughput
Infinitely scale as your business expands, without any additional planning or cost to execute so you save time and money.

4. Flexibility and freedom
Easily add and remove new targets as often as you need to – with a “ReadOnceWriteMany” method you never have to worry about impacting the production database.
5. Hundreds of data pipelines can stream billions of events a day
Whether it’s the busiest travel day of the year or Black Friday, Striim can support your busiest times of the year and stream billions of events a day.


(Usage-based pricing that scales
with your business needs
Scale up and down your consumption as needed. Whether your processing billions of events per hour or on stand-by for new events, Striim meters exactly what you use.)

6.. Real-Time operations
Build a responsive supply chain

Transform your business with highly responsive digital supply chains and operations powered by real-time data streaming.

<!--Whether you’re a Retailer, Manufacturer, or Airline, your operations and supply chain need to be ready to adapt quickly to fast-changing 
customer demands or unforeseen events. Powering your analytics or predictive modeling with the freshest data is critical and can make the 
difference between delighting or losing your customers. Striim enables you to pump terabytes of data with sub-second latency into cloud-based 
data lakehouses and data warehouses for analytics and machine learning enabling you to react to changes at the speed of thought.

-->


Our REST API lets you ensure that your data delivery Service Level Agreements (SLAs) are guaranteed by 
leveraging centralized monitoring and observability tools.


Linked Lists
Heaps
Trees
Graphs
Randomized Algorithms
Functional Algorithms
Dynamic Programming and Backtracking
Arrays
Stacks and Queues
Strings
Bit Manipulation
Object Oriented Design
Networking and Distributed Systems
Systems Design


Arrays
Most Frequently Occurring Item in an Array (Solution)
03:39
Preview
00:53
Common Elements in Two Sorted Arrays (Python)
1 question
Common Elements in Two Sorted Arrays (Java)
1 question
Common Elements in Two Sorted Arrays (Solution)
03:37
Is One Array a Rotation of Another? (Difficulty = **)
01:06
Is One Array a Rotation of Another? (Python)
1 question
Is One Array a Rotation of Another? (Java)
1 question
Is One Array a Rotation of Another? (Solution)


Strings
Non-Repeating Character (Difficulty = **)
00:47
Non-Repeating Character (Python)
1 question
Non-Repeating Character (Java)
1 question
Non-Repeating Character (Solution)
02:48
One Away Strings (Difficulty = ***)
02:17
One Away Strings (Python)
1 question
One Away Strings (Java)
1 question
One Away Strings (Solution)
03:05
One Away Strings (Solution in Pseudocode)



Two D arrays
Assign Numbers in Minesweeper (Difficulty = **)
02:10
Assign Numbers in Minesweeper (Python)
1 question
Assign Numbers in Minesweeper (Java)
1 question
Assign Numbers in Minesweeper (Solution)
04:46
Find Where to Expand in Minesweeper (Difficulty = ***)
03:35
Find Where to Expand in Minesweeper (Python)
1 question
Find Where to Expand in Minesweeper (Java)
1 question
Find Where to Expand in Minesweeper (Solution)
10:52
Find Where to Expand in Minesweeper (Solution in Pseudocode)
04:23
Rotating 2D Array (Difficulty = ***)
01:19
Rotating a 2D Array by 90 Degrees (Python)
1 question
Rotating a 2D Array by 90 Degrees (Java)
1 question
Rotating 2D Array (Out-of-Place Solution)
05:20
Rotating 2D Array (In-Place Solution)
07:05
Rotating 2D Array (In-Place Solution in Pseudocode)



LinkedLists and Trees:
N-th Element of a Linked List (Difficulty = **)
02:29
N-th Element of a Linked List (Python)
1 question
N-th Element of a Linked List (Java)
1 question
N-th Element of a Linked List (Solution)
05:07
Is This a Binary Search Tree? (Difficulty = **)
03:08
Is This a Binary Search Tree? (Python)
1 question
Is This a Binary Search Tree? (Java)
1 question
Is This a Binary Search Tree? (Solution)
02:43
Is This a Binary Search Tree? (Solution in Pseudocode)
05:05
Lowest Common Ancestor (Difficulty = ***)
03:24
Lowest Common Ancestor (Python)
1 question
Lowest Common Ancestor (Java)
1 question
Lowest Common Ancestor (Solution)
07:01
Lowest Common Ancestor (Solution in Pseudocode)
07:41




The Earth Engine Public Data Catalog includes a range of geospatial data, including satellite data like Landsat, 
Sentinel-2, and MODIS, as well as geophysical, weather, climate and demographic data. You can use this API to filter 
these data collections to identify the data you need for your analysis, and then to fetch the pixels you need from 
any of these datasets on demand. To get started, you can search for and view documentation about specific datasets.

## ..

Google Earth Engine is a cloud-based platform for planetary-scale geospatial analysis that brings Google's massive computational
 capabilities to bear on a variety of high-impact societal issues including deforestation, drought, disaster, disease, food security, 
water management, climate monitoring and environmental protection. It is unique in the field as an integrated platform designed to 
empower not only traditional remote sensing scientists, but also a much wider audience that lacks the technical capacity needed to 
utilize traditional supercomputers or large-scale commodity cloud computing resources.



A planetary-scale platform for Earth science data & analysis
Earth Engine's public data archive includes more than forty years of historical imagery and scientific datasets, updated and expanded daily.

::


Google Earth Engine is a geospatial processing service. With Earth Engine, you can perform geospatial processing at scale, 
powered by Google Cloud Platform. The purpose of Earth Engine is to:

Provide an interactive platform for geospatial algorithm development at scale
Enable high-impact, data-driven science
Make substantive progress on global challenges that involve large geospatial datasets









𝐆𝐨𝐥𝐝𝐞𝐧 𝐑𝐮𝐥𝐞𝐬 𝐢𝐧 𝐚 𝐅𝐫𝐨𝐧𝐭𝐞𝐧𝐝 𝐒𝐲𝐬𝐭𝐞𝐦 𝐃𝐞𝐬𝐢𝐠𝐧 𝐈𝐧𝐭𝐞𝐫𝐯𝐢𝐞𝐰

If we are dealing with a user-intensive application, it's good to use lazy loading techniques for better performance.
To prevent blocking of the UI thread, we should consider using Web Workers. Remember about its drawbacks.
For responsive design, consider using a mobile-first approach with media queries.
If the system requires a complex UI with a lot of user interaction, consider using a frontend framework like React, Angular, or Vue.
If you need to handle and maintain the state of the application efficiently, consider using state management libraries like Redux or Mobx.
To make the website accessible, ensure proper use of ARIA attributes and semantic HTML.
If the application requires real-time data updates, consider using Websockets or Server-Sent Events.
If the system requires seamless navigation between different parts of the application, consider using client-side routing.
For optimizing large lists or tables in the UI, consider using techniques like windowing.
To deal with form validation and data collection, consider using libraries like Formik or react-hook-form.
If the system has a component-based architecture, ensure proper component composition.
If the system needs to store data in the client-side, we should consider using Cookies, Local Storage, or IndexedDB based on the use case.
To reduce the initial load time of the application, implement code splitting.
If the application needs to work offline, implement a service worker and build a Progressive Web App (PWA).
For efficient error handling, use a centralized error handling system.
When dealing with APIs, consider using GraphQL for efficient data retrieval.
If the system requires frequent style changes based on props, consider CSS-in-JS libraries.
If the system has multiple similar components, consider using higher-order components or render props for code reusability.
If the system needs to be SEO-friendly, implement server-side rendering (SSR) or pre-rendering.
For large scale applications, use a monorepo structure for easy package management.
When dealing with asynchronous data, consider using Promises or async/await for better code readability and error handling.
For handling complex animations, consider using libraries like Framer Motion or React Spring.
If the application needs to support multiple themes, consider context API and CSS variables.
If the application needs to support internationalization, consider libraries like i18next.
To ensure the performance of the application, make sure to use the browser's Performance API.
For testing components and business logic, consider using libraries like Jest and React Testing Library.
To enforce code style and prevent bugs, consider using linters and formatters like ESLint and Prettier.
To ensure your frontend is accessible to all users, you should follow WCAG guidelines and use tools for checking accessibility compliance.
For maintaining code quality and enforcing coding standards, use static type checkers like TypeScript and linters such as ESLint.
Consider implementing state management libraries like Redux or Context API for predictable state management in complex applications with many components
If your application deals with real-time data, consider using WebSockets or libraries such as Socket.IO for real-time, bidirectional communication between the client and the server.
For managing side effects in your application, libraries like Redux-Thunk or Redux-Saga can be considered.
If your application requires routing, libraries like React-Router can help manage different views for your app.











Google Earth Engine combines a multi-petabyte catalog of satellite imagery and geospatial datasets with
 planetary-scale analysis capabilities. Scientists, researchers, and developers use Earth Engine to detect changes, 
map trends, and quantify differences on the Earth's surface. Earth Engine is now available for commercial use, and 
remains free for academic and research use.


Satellite Imagery + Your Algorithms = Real World Applications
<!--Scientists and non-profits use Earth Engine for remote sensing research, predicting disease outbreaks, natural resource management, and more.
https://earthengine.google.com/case_studies/-->






## climate + Weather
Surface Temp(+data):
Thermal satellite sensors can provide surface temperature and emissivity information. The Earth Engine data catalog includes both land and sea 
surface temperature products derived from several spacecraft sensors, including MODIS, ASTER, and AVHRR, in addition to raw Landsat thermal data.


Climate: 
Climate models generate both long-term climate predictions and historical interpolations of surface variables. The Earth Engine catalog includes 
historical reanalysis data from NCEP/NCAR, gridded meteorological datasets like NLDAS-2, and GridMET, and climate model outputs like the University 
of Idaho MACAv2-METDATA and the NASA Earth Exchange’s Downscaled Climate Projections.



Atmospheric
You can use atmospheric data to help correct image data from other sensors, or you can study it in its own right. 
The Earth Engine catalog includes atmospheric datasets such as ozone data from NASA's TOMS and OMI instruments and the 
MODIS Monthly Gridded Atmospheric Product.


Weather:
Weather datasets describe forecasted and measured conditions over short periods of time, including precipitation, temperature, humidity, and wind, and other variables. Earth Engine includes forecast data from NOAA's Global Forecast System (GFS) and the NCEP Climate Forecast System (CFSv2), as well as sensor data from sources like the Tropical Rainfall Measuring Mission (TRMM).


# Imagery

Landsat, a joint program of the USGS and NASA, has been observing the Earth continuously from 1972 through the present day. Today the Landsat satellites image the entire Earth's surface at a 30-meter resolution about once every two weeks, including multispectral and thermal data.


The Copernicus Program is an ambitious initiative headed by the European Commission in partnership with the European Space Agency (ESA). The Sentinels include all-weather radar images from Sentinel-1A and -1B, high-resolution optical images from Sentinel 2A and 2B, as well as ocean and land data suitable for environmental and climate monitoring from Sentinel 3.



The Moderate Resolution Imaging Spectroradiometer (MODIS) sensors on NASA's Terra and Aqua satellites have been acquiring images of the Earth daily since 1999, including daily imagery, 16-day BRDF-adjusted surface reflectance, and derived products such as vegetation indices and snow cover.


High-resolution imagery captures the finer details of landscapes and urban environments. The US National Agriculture Imagery Program (NAIP) offers aerial image data of the US at one-meter resolution, including nearly complete coverage every several years since 2003.



# Geophysical

Terrain:
Digital Elevation Models (DEMs) describe the shape of Earth’s terrain. The Earth Engine data catalog contains several global DEMs such as Shuttle Radar Topography Mission (SRTM) data at 30-meter resolution, regional DEMs at higher resolutions, and derived products such as the WWF's HydroSHEDS hydrology database.



Land Cover:
Land cover maps describe the physical landscape in terms of land cover classes such as forest, grassland, and water. Earth Engine includes a wide variety of land cover datasets, from near real-time Dynamic World to global products such as ESA World Cover.



Crop land:
Cropland data is key to understanding global water consumption and agricultural production. Earth Engine includes a number of cropland data products such as the USDA NASS Cropland Data Layers, as well as layers from the Global Food Security-Support Analysis Data (GFSAD) including cropland extent, crop dominance, and watering sources.


<!--Data from other satellite image sensors is available in Earth Engine as well, including night-time imagery from the Defense Meteorological Satellite Program's Operational Linescan System (DMSP-OLS), which has collected imagery of night-time lights at approximately 1-kilometer resolution continuously since 1992.

-->















