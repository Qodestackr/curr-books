1. Setup Django with: DRF, SSL, Prod/Dev, Docker Compose, CKAN, GitHub action, Docker sample for the app and whatever else I might need

### CKAN installation

CKAN issa data portal that can run in a seperate application/its own server...

<!-- It is not just a Python package that you install within your Django project like other packages. -->

Setup CKAN server:

- Install on a seperate server/instance
- Configure what CKAN needs for itself
- Play around with the API(No Django yet)
- Configure CKAN in Django
  <!--
  Once CKAN is installed and running, you can configure your Django project to interact with CKAN's API. You can use the requests library or other HTTP client libraries to make API calls to CKAN from your Django views. -->
  Data Synchronization:

Decide on the data you want to manage with CKAN and how it will be synchronized with your Django database. You may need to write scripts or custom management commands in Django to handle data synchronization.

TODO: SETUP ORGS PROGRAMMATICALLY BASED ON USER NEEDS, BUT FOR NOW, JUST ONE ORG BASED ON
DATA TYPE, i.e GIS AND GTFS(NAME THEM ACCORDINGLY WITH DESCRIPTIONS)

<!--
AFTER THOUGHTS ::
User Authentication:

If you want to provide user authentication for CKAN, you'll need to implement Single Sign-On (SSO) or some other authentication mechanism between your Django app and CKAN.
Data Portal Features:

CKAN has various data portal features like dataset creation, data publishing, and metadata management. You'll need to implement these features in your Django app using CKAN's API. -->

---

start venv
django-admin startproject geox-data-portal
pip install needed dependencies
configure settings and DRF
Setup/ Configure SSL in settings

Prod/Dev: DB connections, static files, media,
(base.py, dev.py, prod.py)

Dockerize&Compose

Integrate CKAN: pip install ckan
Configure CKAN in Django

Set up a GitHub Actions workflow to automate CI/CD processes.
Define build, test, and deployment steps in the workflow.
