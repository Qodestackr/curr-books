Swift Core Analytics Engine

User Registration and Authentication
- Register with Social Auth
- Credentials and API keys

<!-- - Build roles -->

## Always have API documentation


*User dashboard: Generate API key(auth token for accessing platform's API securely)


## Requesting Geospatial data
Make HTTP Requests, necessary params

## Recieving Geospatial data
- Platform's API processes request, retrieves requested data from GEE, and sends a response
- The client application retrieves the geospatial data in desired format(GeoJSON, raster images)

<!-- Geospatial analysis -->

## Viz and Mapping

Developers use data recieved to create visualizations and interactive maps in their applications using open layers and leaflet


## Optional: Real-Time updates
Devs to subscribe to recieve them updates

