GIS data management:

- GEE
- PostGIS

Backend/ Services

# Django (REST APIs)

<!--
- DRF
- Channels: real-time: notifications, location tracing
- PostGIS
- Serverless cache
-->

Deployment:

- Serverless
- Docker/Kubernetes

# GIS data sharing and API platforms

- REST
- API doc
- SaaS model: SaaS platform for other devs/ fields can subscribe and access geospatial data and analytics as a service
  (GIS analytics as a Service)

# FOCUS: MVP

- Data ingestion and management with GEE
  Satellite imagery or so ingested and stored in cloud sorage services like S3/Google Cloud Storage

- Data Processing
  Before analysis, data may require preprocessing to align or mosaic satellite imagery. GEE excels in this area,
  providing tools to perform tasks like image composition, cloud masking, and temporal assignment

:Time series analysis (Monitor vegetation health, land cover changes, urban development patterns)

:PostGIS complements GEE by providing spatial DB for efficient storage and management of data

<!-- Store non-image data here, meta-data related to satellite imagery and so on... -->

:Geospatial Queries: PostGIS <!--E.g users can query data within a specific polygon or search for points of interest in a given area-->

- Basic auth to access services
- Visualize on frontend...(Use right tools)
- REST APIs to serve and request that data
- Cloud-based hosting

<!-- Its hard to design an analytics platform from get-go
Listen to users feedback and iterate/ improve upon

:Focus on providing large datasets, and common generic analytics.. End users can always pull to perfom
other custom data analysis
-->

Benefits:
Efficient storage: Objects, PostGIS, GEE
Comprehensive platform
GEE offloads my infrastructure from computational burden thus easing scaling demands

Challenges
Limited dev free tier, high cloud-service costs

<!--
Cost management practices/ strategies: data compression, intelligent data storage pracices
-->

# Data flow:

1. End user interacts with my platform through client app or API to access geospatial data and analytical tools
2. Data Ingestion and Storage: Data from various sources(satellite imagery, local data, agencies, user-provided, climate,etc)
   is ingested into the platform

Data is then stored in storage services like objects(S3), PostGIS, Cassandra 3. Data processing and analsis
: GEE handles this, for time-series, complex geospatial operations, cloud-based processing
: Turf.js and other libs used to handle analytics and calculations
: GEE processes satellite imagery and generates analytics-ready data for further use

4. Real-Time and on demand analytics
   *Regions and times
   *Continous monitoring
5. The platform providers APIs with data services for users to access and retrieve geospatial data programmatically

6. Viz and Mapping

7. Data Export and Download
   In formats such as CSV, GeoJSON, Raster Images

## GEE the big thing

Before performing analysis on satellite imagery, data often requires preprocessing to ensure it is suitable for analysis.
GEE is a platform that excels in this area by providing a set of tools and functionalities to perform various preprocessing tasks.

- Image Composition:
  Satellite imageru captured at diff times and dates, leading to multiple images of the same area

\*This is the process of combining multiple images to create a single composite image that represents the area at
a specific time or season

> This is crucial to remove cloud cover, atmospheric disturbances, and other artifacts that may affect the quality of the data
> for analysis

- Cloud Masking
  Used to mask out cloudy pixels from the image, improving the quality of imagery

- Temporal alignment

- Processing efficiency

- Automated processing pipelines

- Access to preprocessed data

<!-- Real-time location on an interactive map, enabling them to estimate times and plan trips -->
<!-- Route planning and navigation
Suggest best routes and transit options based on user's current loc

If offline: Fallback to Turf.js on frontend and utilize available cached data to help: Nice feature!!

Create a virtual file system and load user's often accessed data first...etc then we will see
 -->

<!-- Nearby shops, stations, and so on...
Common stops, 
 -->

 <!-- Estimate arrivals -->

 <!-- Alerts and notifcations, geofencing -->
 <!-- Ratings and reviews -->
 <!-- Customizable favorites, History of prev use -->