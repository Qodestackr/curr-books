**What I do**:
_Strong programming skills:_

- JavaScript/ TypeScript
- React, React Native, Next.js
- Django, Node.js, Nginx
- REST APIs, GraphQL, Webhooks, and microservices
- Serverless development,
- Apache Cassandra, MongoDB, PostGIS, PostgreSQL, Search Engines(Elastic search)
- EFK: Elasticsearch, Fluentd, Kibana (<!--know that ELK exists-->)
- Basics DevOps principles with tools like: Docker, K8s, Ansible, Pulumi, GitHub Actions, and linux automation.

Projects:

**Remo:** A remote code execution engine
Built with Docker Compose, Node.js, Sentry(Logging), MongoDB, and React.

**Dazzle HR:** A SaaS business model.

Emails and efficient messaging

Sales analytics with location/ context aware approach. We implement a context-aware user and information management to help with demographics when dealing with sales.

SaaS, Handling sales and customer relationship management, strong GIS and geospatial development. My Open source contributions in geospatial contexts

<!--
- Location-aware applications
- Geographic data in business processes
-->

TODO: LEARN FROM AN INDUSTRY SPECIFIC EXPERTISE
OPTIMIZING SALES WORKFLOWS: 

## EFK stack

1. Elasticsearch - component for storing and indexing log data. Enables fast and efficient search capabilities
2. Fluentd - A lightweight loog collector that can efficiently collect logs from various sources and forwads them to Elasticsearch for indexing.
3. Kibana - Data visualization and analysis features.
<!-- Create: Custom dashboards, charts, graphs -->
