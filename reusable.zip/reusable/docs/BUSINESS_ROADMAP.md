Sales and Marketing fundamentals

**Develop sales pitches**

Google Analytics

ArcGIS- more features in 3D realm visualization


GIS business analyst

Optimal site location
Market segmentation(demographics, customer behavior, lifestyle preferences)
Competitive analysis 

<!-- Data sources and collections:
- demographic data
- consumer spending data
- business data
-->


Data visualization: Informative and visually appealing maps and reports for business presentations

<!-- Esri materials to learn more -->
