import pandas as pd
import geopandas as gpd
import json
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

CONFIG_FILE_PATH = "data_sources.json"

def load_csv(source):
    try:
        df = pd.read_csv(source)
        return df
    except FileNotFoundError as e:
        logger.error(f"CSV file not found: {source}")
    except Exception as e:
        logger.error(f"Error loading CSV file {source}: {str(e)}")
    return None


def load_html(source):
    try:
        df = pd.read_html(source)[0]
        return df
    except Exception as e:
        logger.error(f"Error loading HTML file {source}: {str(e)}")
    return None


def load_postgresql(source):
    try:
        # Code to fetch data from PostgreSQL database using psycopg2 or other libraries
        pass
    except Exception as e:
        logger.error(f"Error connecting to PostgreSQL: {str(e)}")
    return None


def load_excel(source):
    try:
        df = pd.read_excel(source)
        return df
    except FileNotFoundError as e:
        logger.error(f"Excel file not found: {source}")
    except Exception as e:
        logger.error(f"Error loading Excel file {source}: {str(e)}")
    return None


def load_json(source):
    try:
        with open(source, "r") as file:
            data = json.load(file)
        df = pd.DataFrame(data)
        return df
    except FileNotFoundError as e:
        logger.error(f"JSON file not found: {source}")
    except Exception as e:
        logger.error(f"Error loading JSON file {source}: {str(e)}")
    return None


def create_df_with_fallback(data_sources):
    for source in data_sources:
        if source.endswith('.csv'):
            df = load_csv(source)
        elif source.endswith('.html'):
            df = load_html(source)
        elif source.startswith('postgresql://'):
            df = load_postgresql(source)
        elif source.endswith('.xlsx'):
            df = load_excel(source)
        elif source.endswith('.json'):
            df = load_json(source)
        else:
            logger.warning(f"Unsupported data source: {source}")
            continue

        if df is not None and not df.empty:
            return df

    logger.error("Unable to load data from any of the specified sources.")
    return None


def main():
    try:
        with open(CONFIG_FILE_PATH, "r") as config_file:
            config = json.load(config_file)
            data_sources = config.get("data_sources", [])
    except FileNotFoundError:
        logger.error(f"Config file not found: {CONFIG_FILE_PATH}")
        return

    df = create_df_with_fallback(data_sources)

    if df is not None:
        logger.info(df.head())
    else:
        logger.error("Unable to load data from any of the specified sources.")


if __name__ == "__main__":
    main()
