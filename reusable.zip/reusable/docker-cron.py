import subprocess
import schedule
import time

def run_cleanup_script():
    subprocess.call(['bash', '/path/to/your/bash/script.sh'])

# Schedule the script to run every hour
schedule.every().hour.do(run_cleanup_script)

while True:
    schedule.run_pending()
    time.sleep(1)
