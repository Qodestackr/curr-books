EcoSpatial-Portal:
CKAN as docker app/project or vice versa?

===========================================
_gee_remote_sensing/analytics
_data_parsers(take and transform into what is needed e.g GTFS ... GeoJSON or whatever for storage)
_analytics
_backups
_harvesters
_adapters
===========================================

- Swiftbird: email, webhooks, reminders, notifications
- SwiftAuth: favorite routes, sso/social, policies

Install Postgres, check OS specifics

PostGIS Extension Installation:

Setup DB:

```bash
sudo -u postgres psql
```

```SQL

CREATE USER qodestackr WITH PASSWORD 'local';

GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO qodestackr;

\q
```

Option 2: Connect to the default PostgreSQL database:
If you don't need a separate database for the "qodestackr" user, you can connect to the default PostgreSQL database using the command sudo psql -U qodestackr postgres. This will connect to the "postgres" database with the "qodestackr" user.

```SQL
sudo psql -U qodestackr swift_transit;

SELECT current_user, current_database();

```

Connect to your "swift_transit" database using the following command:

```psql -U qodestackr -d swift_transit

```
